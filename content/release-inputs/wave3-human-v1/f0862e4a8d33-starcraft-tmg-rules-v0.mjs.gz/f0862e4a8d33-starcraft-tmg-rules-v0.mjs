#!/usr/bin/env node

import { readFile } from "node:fs/promises";
import path from "node:path";

export const STARCRAFT_TMG_RULES_SCHEMA = "starcraft_tmg_rules_v0";
export const STARCRAFT_TMG_STATE_SCHEMA = "starcraft_tmg_state_v0";

const PHASES = ["movement", "assault", "combat", "scoring"];
const SIDE_KEYS = ["player1", "player2"];
const FACTION_COLORS = { Terran: "#41b6e6", Zerg: "#a855f7", Protoss: "#f4c95d" };
const OFFICIAL_BOARD_SIZES = {
  standard: { widthInches: 54, heightInches: 36 },
  skirmish: { widthInches: 36, heightInches: 36 },
};

const TERRAIN_TRAIT_DEFAULTS = {
  "lost-temple-wall": { name: "Blocking Obstacle H2", exampleObject: "Lost Temple Wall", rulesClassification: "terrain-effect-preset", category: "blocking", footprint: "rect", widthInches: 5, heightInches: 1.4, heightTier: 2, blocksLos: true, providesCover: true, difficult: false, impassable: true, hazard: false, effectKeywords: ["blocks-los", "cover", "impassable", "height-2"] },
  "temple-obelisk": { name: "Tall Blocking Obstacle H3", exampleObject: "Temple Obelisk", rulesClassification: "terrain-effect-preset", category: "blocking", footprint: "circle", widthInches: 2, heightInches: 2, heightTier: 3, blocksLos: true, providesCover: true, difficult: false, impassable: true, hazard: false, effectKeywords: ["blocks-los", "cover", "impassable", "height-3"] },
  "shrub-cover": { name: "Cover Area H1", exampleObject: "Shrubs", rulesClassification: "terrain-effect-preset", category: "area-cover", footprint: "rect", widthInches: 4, heightInches: 3, heightTier: 1, blocksLos: false, providesCover: true, difficult: true, impassable: false, hazard: false, effectKeywords: ["cover", "difficult", "height-1"] },
  "high-ground-cliff": { name: "Elevated Blocking Area H3", exampleObject: "High Ground Cliff", rulesClassification: "terrain-effect-preset", category: "elevation", footprint: "rect", widthInches: 8, heightInches: 4, heightTier: 3, blocksLos: true, providesCover: true, difficult: true, impassable: false, hazard: false, effectKeywords: ["blocks-los", "cover", "difficult", "height-3"] },
  "mineral-field": { name: "Cover Scatter H1", exampleObject: "Mineral Field", rulesClassification: "terrain-effect-preset", category: "scatter", footprint: "rect", widthInches: 3, heightInches: 1.8, heightTier: 1, blocksLos: false, providesCover: true, difficult: true, impassable: false, hazard: false, effectKeywords: ["cover", "difficult", "height-1"] },
  "vespene-geyser": { name: "Blocking Scatter H2", exampleObject: "Vespene Geyser", rulesClassification: "terrain-effect-preset", category: "blocking", footprint: "circle", widthInches: 2.6, heightInches: 2.6, heightTier: 2, blocksLos: true, providesCover: true, difficult: false, impassable: true, hazard: false, effectKeywords: ["blocks-los", "cover", "impassable", "height-2"] },
  "xelnaga-tower": { name: "Tall Objective Blocker H3", exampleObject: "Xel'Naga Tower", rulesClassification: "terrain-effect-preset", category: "vision", footprint: "circle", widthInches: 2.4, heightInches: 2.4, heightTier: 3, blocksLos: true, providesCover: true, difficult: false, impassable: true, hazard: false, effectKeywords: ["blocks-los", "cover", "impassable", "objective", "height-3"] },
  "destructible-rocks": { name: "Destructible Blocker H2", exampleObject: "Destructible Rocks", rulesClassification: "terrain-effect-preset", category: "blocking", footprint: "rect", widthInches: 4, heightInches: 2, heightTier: 2, blocksLos: true, providesCover: true, difficult: false, impassable: true, destructible: true, hazard: false, effectKeywords: ["blocks-los", "cover", "impassable", "destructible", "height-2"] },
  "lava-flow": { name: "Hazard Area", exampleObject: "Lava Flow", rulesClassification: "terrain-effect-preset", category: "hazard", footprint: "rect", widthInches: 5, heightInches: 2.5, heightTier: 0, blocksLos: false, providesCover: false, difficult: true, impassable: false, hazard: true, hazardDamage: 1, effectKeywords: ["difficult", "hazard", "height-0"] },
};

export const RULE_MATRIX = [
  row("src_live_firestore_units", "source", "Live Firestore unit collection is pulled and normalized.", "official app Firestore chain", ["check_data_units_count"]),
  row("src_live_firestore_cards", "source", "Tactical/faction cards and game cards are pulled from live Firestore.", "official app Firestore chain", ["check_cards_and_game_cards_count"]),
  row("src_update_policy", "source", "Data package records source version, pulledAt, source mode, and known exactness gaps.", "project-d source discipline", ["check_source_update_metadata"]),
  row("profile_stats", "identity", "Unit stats preserve speed, evade, armor, hp, shield, size, tags, keywords, and source id.", "sc-tmg-app UnitCard", ["check_unit_profile_fields"]),
  row("profile_squad_sizes", "identity", "Small/large squad profiles preserve model count, supply, and minerals.", "sc-tmg-app SquadProfile", ["check_squad_profile_fields"]),
  row("board_official_sizes", "board", "Board sizes use official FAQ dimensions: skirmish 36x36 inches and standard 54x36 inches.", "official FAQ board size", ["fixture_board_official_sizes"]),
  row("board_base_to_base_measurement", "board", "Distances and LOS use base-to-base measurement abstractions rather than true model-eye line of sight.", "official FAQ LOS answer", ["fixture_base_to_base_distance"]),
  row("board_base_footprints", "board", "Unit bases preserve per-unit footprint shape and dimensions where known, including non-round Hydralisk oval bases.", "official/product base lists + Project D review overrides", ["fixture_base_footprint_dimensions"]),
  row("roster_minerals", "construction", "Roster validation enforces mineral limits for selected unit sizes and upgrades.", "sc-tmg-app army-calc", ["fixture_roster_mineral_limit"]),
  row("roster_faction", "construction", "Roster validation rejects mixed faction units unless a future mode allows it.", "v0 construction scope", ["fixture_roster_faction_lock"]),
  row("round_supply_pool", "supply", "Round supply pool starts from mission card and escalates each round.", "rules notes 8.3.1", ["fixture_supply_pool_round_two"]),
  row("dynamic_supply", "supply", "Destroyed/off-field units free supply; model-loss supply brackets are scoped until exact profile table import.", "rules notes 6.1/6.2", ["fixture_supply_onfield_count"]),
  row("dynamic_supply_bracket", "supply", "Current Supply drops when a unit is reduced to its low-model bracket, with exact per-card brackets reviewable until official table import.", "rules notes 6.1/6.2 example", ["fixture_dynamic_supply_low_model_bracket"]),
  row("phase_sequence", "turn", "Round phases advance Movement -> Assault -> Combat -> Scoring -> next Movement.", "rules notes 8.4/8.6/8.8", ["fixture_phase_sequence"]),
  row("per_phase_activation", "turn", "Units activate once per Movement, Assault, and Combat phase.", "rules notes key finding", ["fixture_per_phase_activation_marker"]),
  row("alternating_activation", "turn", "After a unit activation, active side alternates to the opponent when that opponent still has usable activations.", "official news / rules notes alternating activations", ["fixture_alternating_activation_after_move"]),
  row("pass_phase", "turn", "Pass marks remaining activations for that side in the current phase.", "rules notes 8.4.2", ["fixture_pass_marks_phase"]),
  row("first_pass_marker", "turn", "The first side to Pass in a phase claims the next phase first-player marker.", "official news strategic passing", ["fixture_first_pass_sets_next_first_player"]),
  row("active_ability_once", "turn", "Active ability use is tracked once per round unless a future exact ability says otherwise.", "rules notes active ability policy", ["fixture_active_ability_once_marker"]),
  row("unit_active_ability_markers", "turn", "Unit active abilities can create board markers or toggle statuses, including Adept Shade tokens and Zerg Burrowed status.", "unit ability text + sc-tmg-app Battle surface", ["fixture_adept_shade_marker", "fixture_roach_burrow_status"]),
  row("reaction_limit", "turn", "Reaction use is tracked once per activation window and remains reviewable until full timing text is imported.", "rules notes reaction policy", ["fixture_reaction_marker"]),
  row("card_resource_panel", "resources", "Faction/Tactical cards expose resource pools, Exhausted/used markers, and Active/Reaction/Passive ability text to the battle UI.", "sc-tmg-app match + tactical_cards", ["fixture_card_resource_state"]),
  row("card_resource_transition", "resources", "Card resources can be spent/exhausted through an executable transition and reset at the next round.", "sc-tmg-app army resources + rules notes cards", ["fixture_card_resource_use_transition"]),
  row("unit_upgrade_resource_costs", "resources", "Unit upgrade abilities preserve CP/BM/PE costs and timing tags for resource review.", "tactical_cards + army_units activation text", ["fixture_upgrade_resource_costs"]),
  row("army_builder_slots_resources", "construction", "Army builder computes minerals, tactical-card gas, unit slots, and card resources using the original app army-calc contract.", "sc-tmg-app army-calc", ["fixture_army_builder_summary"]),
  row("army_builder_import_export", "construction", "Army lists export/import the original app text format, including faction cards, tactical cards, mission, deployment, sizes, and upgrades.", "sc-tmg-app armyToText/textToArmy", ["fixture_army_builder_text_roundtrip"]),
  row("pregame_mission_deployment_draft", "construction", "Mission and Deployment selections are linked to the builder and battle table; exact veto/draft UX remains reviewable.", "official news Draft System / Command Centre", ["fixture_builder_mission_deployment_selection"]),
  row("formation_deploy", "deployment", "Small/large unit profiles deploy as multi-model formations with profile size, model count, selected upgrades, and supply visible.", "sc-tmg-app squad profiles", ["fixture_multi_model_formation"]),
  row("formation_no_overlap", "deployment", "Movement, deploy, and charge candidates reject overlapping model bases unless a specific ability explicitly permits moving through bases.", "core base overlap rule / Burrow exceptions as text", ["fixture_base_overlap_rejected"]),
  row("movement_deploy", "movement", "Reserve units can deploy when available supply allows.", "rules notes Movement Phase", ["fixture_deploy_from_reserve"]),
  row("movement_move", "movement", "On-field units can move up to parsed Speed in inches.", "rules notes Movement Phase", ["fixture_move_within_speed"]),
  row("movement_disengage_tactical_mass", "movement", "Engaged units can Disengage; Tactical Mass allows later Shoot/Charge when own Current Supply exceeds engaging enemy Current Supply.", "rules notes Tactical Mass / Disengage", ["fixture_disengage_tactical_mass"]),
  row("movement_entry_edge", "movement", "Deployment from reserve uses side entry-edge geometry for Project D scenario maps.", "deployment cards / Command Centre entry edges", ["fixture_entry_edge_deploy"]),
  row("movement_terrain_path", "movement", "Movement path cost reports difficult, hazardous, and impassable terrain crossings.", "official Command Centre terrain guidance", ["fixture_terrain_path_cost"]),
  row("assault_shoot", "assault", "Assault phase ranged weapons produce shoot legal actions when target, range, and activation state allow it.", "rules notes Assault Phase", ["fixture_assault_shoot"]),
  row("assault_los_required", "assault", "Ranged attack legality checks base-to-base line of sight and terrain height tier blockers unless Indirect Fire applies.", "official FAQ LOS / height tier", ["fixture_los_blocks_shooting"]),
  row("assault_charge", "assault", "Charge closes to melee range and resolves eligible close-combat/impact-capable attacks.", "rules notes Assault Phase", ["fixture_charge_transition"]),
  row("assault_charge_terrain", "assault", "Charge route checks impassable and difficult terrain using the same path evaluator as movement.", "Project D terrain transition", ["fixture_charge_path_blocked"]),
  row("combat_fight", "combat", "Combat phase fight is legal only for engaged units with close-combat weapons.", "rules notes Combat Phase", ["fixture_combat_fight_engaged"]),
  row("dice_attack_pool", "combat", "Attack Pool = current models x RoA; target number uses D6 natural 1/6 bounds.", "sc-tmg-app combat-engine", ["fixture_attack_pool_expectation"]),
  row("dice_surge_pool", "combat", "Surge/Critical moves expected dice from Armour Pool into Damage Pool when target tags match; DODGE prevents bypass dice first.", "sc-tmg-app combat-engine", ["fixture_surge_bypass"]),
  row("dice_armour_pool", "combat", "Armour Pool successes remove dice; failures continue to Damage Pool.", "sc-tmg-app combat-engine", ["fixture_armour_pool"]),
  row("dice_evade_pool", "combat", "Evade is applied only when explicitly available by rule/state/context.", "sc-tmg-app combat-engine", ["fixture_evade_pool"]),
  row("dice_pool_trace_ui", "combat", "Legal attack previews expose Attack/Surge/Armour/Evade/Damage pool trace lines for UI inspection.", "Project D combat explainability", ["fixture_three_pool_trace"]),
  row("damage_models", "damage", "Damage Pool dice x weapon DMG removes full models and leaves a damage marker for carryover.", "rules notes 8.7.4", ["fixture_damage_carryover"]),
  row("damage_shields", "damage", "Shield values are treated as extra durability before HP in v0 expected-damage resolution.", "rules notes shield clarification", ["fixture_shield_durability"]),
  row("keyword_pierce", "keywords", "PIERCE changes damage per die against matching target tags.", "sc-tmg-app combat-rules", ["fixture_keyword_pierce"]),
  row("keyword_precision", "keywords", "PRECISION converts expected failed attack dice into hits up to its value.", "sc-tmg-app combat-rules", ["fixture_keyword_precision"]),
  row("keyword_anti_evade", "keywords", "ANTI-EVADE makes Evade target number harder by its value.", "sc-tmg-app combat-rules", ["fixture_keyword_anti_evade"]),
  row("keyword_burst_locked", "keywords", "BURST FIRE and LOCKED IN alter RoA when context matches.", "sc-tmg-app combat-rules", ["fixture_keyword_roa_modifiers"]),
  row("mission_card_fields", "scenario", "Mission card starting supply, game length, params, scoring, and additional conditions are preserved.", "faction_cards mission", ["check_mission_fields"]),
  row("deployment_card_fields", "scenario", "Deployment card map image, game size, and official/community type are preserved.", "faction_cards deployment", ["check_deployment_fields"]),
  row("scoring_center_marker", "scenario", "v0 executable scoring grants control points around a central marker while long-form mission text remains reviewable.", "v0 scenario slice", ["fixture_center_marker_scoring"]),
  row("scoring_destroyed_supply", "scenario", "Destroyed/off-field supply this round can be converted into VP by mission scoring transitions.", "mission scoring text classifier", ["fixture_destroyed_supply_scoring"]),
  row("mission_text_classifier", "scenario", "Mission text is classified into executable center/control/destroyed-supply/objective/marker timing families plus review fragments.", "faction_cards mission text", ["fixture_mission_classifier"]),
  row("mission_full_scoring_families", "scenario", "Official mission cards are all inventoried and classified; center marker, destroyed supply, and broad control families execute while card-specific area/marker timing is reviewable.", "official missions from live data", ["fixture_all_official_missions_classified"]),
  row("scenario_classic_map_catalog", "scenario", "Scenario maps expose Warmachine-style playable layouts backed by classic StarCraft video-game map art.", "Project D scenario-map pattern", ["fixture_scenario_map_catalog"]),
  row("terrain_catalog", "terrain", "Terrain catalog is effect-preset based: footprint, height tier, LOS, cover, difficult, impassable, hazard, and example art are separated from core-rule terrain types.", "official FAQ / Lost Temple kit / Command Centre guidance", ["fixture_terrain_catalog"]),
  row("terrain_piece_transition", "terrain", "Terrain pieces can be materialized as board state objects with source image URL metadata.", "Project D terrain transition", ["fixture_create_terrain_piece"]),
  row("terrain_los_height", "terrain", "Terrain LOS uses segment-footprint intersection and height tiers to return blockers and cover.", "official FAQ LOS / height tier", ["fixture_los_height_tier"]),
  row("terrain_geometry_gap", "terrain", "Exact published deployment-zone vector geometry is still tracked as review until official vectors are available.", "deployment image source", [], "review"),
  row("threat_ranges", "threat", "Threat combines movement, ranged weapon range, and charge/melee reach.", "Project D threat pattern", ["fixture_threat_rows"]),
  row("threat_los_terrain", "threat", "Threat rows expose terrain LOS and cover diagnostics for target selection.", "Project D threat + official terrain", ["fixture_threat_los_diagnostics"]),
  row("ai_legal_consumer", "ai", "Simple AI consumes legal actions, not UI-only commands.", "Project D AI contract", ["fixture_ai_selects_enabled_action"]),
  row("ai_expected_damage_score", "ai", "Simple AI ranks attacks by expected damage/kill pressure and movement by target approach.", "Project D AI contract", ["fixture_ai_attack_preference"]),
  row("ai_training_flags", "ai", "AI outputs keep humanReviewed=false and trainingTruth=false.", "Project D evidence governance", ["fixture_ai_training_flags"]),
  row("service_contract", "service", "Rules service exposes health, metadata, sample-state, roster, legal, apply, phase, threat, simple-ai, benchmark.", "Project D service pattern", ["fixture_service_contract"]),
  row("ui_render_contract", "ui", "Battle UI renders live data counts, official deployment image, tokens, legal actions, threat, AI, and logs.", "Project D E2E gate", ["fixture_ui_render_contract"]),
  row("deploy_readiness", "deploy", "Cloud package/deployment remains pending until user requests StarCraft deployment.", "Project D deployment gate", [], "pending"),
];

function row(id, family, concept, sourceRef, fixtureIds, status = "executable") {
  return {
    id,
    family,
    concept,
    sourceRef,
    status,
    checkItems: fixtureIds.map((fixtureId) => ({ id: `${id}:${fixtureId}`, fixtureId, type: status === "executable" ? "executable" : "reference" })),
  };
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function round(value, digits = 3) {
  const scale = 10 ** digits;
  return Math.round((Number(value) || 0) * scale) / scale;
}

function parseExpectedValue(value) {
  if (typeof value === "number") return value;
  if (value == null || value === "" || value === "-") return 0;
  const text = String(value).trim().toUpperCase();
  const d3 = text.match(/D3\s*(?:\+\s*(\d+))?/);
  if (d3) return 2 + Number(d3[1] || 0);
  const d6 = text.match(/D6\s*(?:\+\s*(\d+))?/);
  if (d6) return 3.5 + Number(d6[1] || 0);
  const first = text.match(/-?\d+(?:\.\d+)?/);
  return first ? Number(first[0]) : 0;
}

function parseSpeed(value) {
  const text = String(value || "0");
  const values = [...text.matchAll(/\d+(?:\.\d+)?/g)].map((match) => Number(match[0]));
  return values[0] || 0;
}

function parseTargetNumber(value, fallback = 4) {
  const parsed = parseExpectedValue(value);
  if (!parsed) return fallback;
  return clamp(parsed, 2, 6);
}

function successProbability(targetNumber) {
  const target = clamp(targetNumber, 2, 6);
  return clamp((7 - target) / 6, 1 / 6, 5 / 6);
}

function parseRange(value) {
  const text = String(value || "").trim().toUpperCase();
  if (!text || text === "-") return 0;
  if (text === "E" || text.includes("ENGAGED")) return 1;
  return parseExpectedValue(text);
}

function splitTags(value) {
  return String(value || "")
    .split(",")
    .map((tag) => tag.trim().toUpperCase().replace("ARMORED", "ARMOURED").replace("AIR", "FLYING"))
    .filter(Boolean);
}

function hasTargetMatch(weapon, defender) {
  const target = String(weapon?.target || "All").toUpperCase();
  if (!target || target === "ALL" || target === "-") return true;
  const tags = splitTags(defender.tags);
  if (target.includes("GROUND")) return tags.includes("GROUND");
  if (target.includes("FLYING") || target.includes("AIR")) return tags.includes("FLYING");
  if (target.includes("LIGHT")) return tags.includes("LIGHT");
  if (target.includes("ARMO")) return tags.includes("ARMOURED");
  return true;
}

function parseKeywords(text) {
  const value = String(text || "").toUpperCase();
  const results = [];
  for (const match of value.matchAll(/PIERCE\s*(?:\[([^\]]+)\]\s*(\d+)|([A-Z' -]+?)\s*\((\d+)\))/g)) {
    results.push({ type: "pierce", tag: (match[1] || match[3] || "").trim().toUpperCase(), damage: Number(match[2] || match[4] || 0) });
  }
  for (const match of value.matchAll(/PRECISION\s*\((\d+)\)/g)) results.push({ type: "precision", count: Number(match[1]) });
  for (const match of value.matchAll(/ANTI[- ]?EVADE\s*\((\d+)\)/g)) results.push({ type: "anti_evade", modifier: Number(match[1]) });
  for (const match of value.matchAll(/BURST\s*FIRE\s*(\d+)\s*"?\s*\((\d+)\)/g)) results.push({ type: "burst_fire", range: Number(match[1]), bonus: Number(match[2]) });
  for (const match of value.matchAll(/CONCENTRATED\s*FIRE\s*\((\d+)\)/g)) results.push({ type: "concentrated_fire", maxKills: Number(match[1]) });
  for (const match of value.matchAll(/DODGE\s*\((\d+)\)/g)) results.push({ type: "dodge", count: Number(match[1]) });
  for (const match of value.matchAll(/IMPACT\s*\((\d+)\)\s*(\d+)\+?/g)) results.push({ type: "impact", dice: Number(match[1]), hit: Number(match[2]) });
  for (const match of value.matchAll(/IMPACT\s*BONUS\s*\((\d+)\)/g)) results.push({ type: "impact_bonus", dice: Number(match[1]) });
  for (const match of value.matchAll(/LOCKED\s*IN\s*\((\d+)\)/g)) results.push({ type: "locked_in", bonus: Number(match[1]) });
  for (const match of value.matchAll(/LONG\s*RANGE\s*(?:\((\d+)\s*"?\)|(\d+)\s*"?)/g)) results.push({ type: "long_range", range: Number(match[1] || match[2] || 0) });
  for (const match of value.matchAll(/TITAN\s*KILLERS\s*(\d+)\+\s*\((\d+)\)/g)) results.push({ type: "titan_killers", minSize: Number(match[1]), damage: Number(match[2]) });
  for (const match of value.matchAll(/CRITICAL\s*HIT\s*\((\d+)\)/g)) results.push({ type: "critical_hit", count: Number(match[1]) });
  for (const match of value.matchAll(/TOUGH\s*\((\d+)\)/g)) results.push({ type: "tough", count: Number(match[1]) });
  if (value.includes("HIDDEN")) results.push({ type: "hidden" });
  if (value.includes("INDIRECT FIRE")) results.push({ type: "indirect_fire" });
  return results;
}

function keywordMax(keywords, type, key) {
  return keywords.filter((keyword) => keyword.type === type).reduce((max, keyword) => Math.max(max, Number(keyword[key] || 0)), 0);
}

function matchingPierce(keywords, defenderTags) {
  const tags = splitTags(defenderTags);
  return keywords
    .filter((keyword) => keyword.type === "pierce" && tags.includes(String(keyword.tag || "").replace("ARMORED", "ARMOURED")))
    .sort((a, b) => Number(b.damage || 0) - Number(a.damage || 0))[0];
}

function matchingTitanKiller(keywords, defenderSize) {
  return keywords
    .filter((keyword) => keyword.type === "titan_killers" && Number(defenderSize || 0) >= Number(keyword.minSize || 0))
    .sort((a, b) => Number(b.damage || 0) - Number(a.damage || 0))[0];
}

function parseSurge(surge) {
  const text = String(surge || "").trim();
  if (!text || text === "-") return { tags: [], dice: 0 };
  const diceMatch = text.match(/\(([^)]+)\)\s*$/);
  const dice = diceMatch ? parseExpectedValue(diceMatch[1]) : 0;
  const tagPart = diceMatch ? text.slice(0, diceMatch.index).trim() : text;
  return { tags: splitTags(tagPart), dice };
}

function distance(a, b) {
  return Math.hypot((a.xInches || 0) - (b.xInches || 0), (a.yInches || 0) - (b.yInches || 0));
}

const MM_PER_INCH = 25.4;

const BASE_FOOTPRINT_OVERRIDES = {
  marine: { shape: "round", widthMm: 32, depthMm: 32, source: "starter/product-base-list: 32mm" },
  medic: { shape: "round", widthMm: 32, depthMm: 32, source: "starter/product-base-list: 32mm" },
  "jim-raynor": { shape: "round", widthMm: 32, depthMm: 32, source: "starter/product-base-list: 32mm" },
  kerrigan: { shape: "round", widthMm: 32, depthMm: 32, source: "starter/product-base-list: 32mm" },
  zergling: { shape: "round", widthMm: 32, depthMm: 32, source: "starter/product-base-list: 32mm" },
  "raptor-zergling": { shape: "round", widthMm: 32, depthMm: 32, source: "starter/product-base-list: zergling family 32mm" },
  "swarmling-zergling": { shape: "round", widthMm: 32, depthMm: 32, source: "starter/product-base-list: zergling family 32mm" },
  "point-defense-drone": { shape: "round", widthMm: 32, depthMm: 32, source: "starter/product-base-list: 32mm" },
  hydralisk: { shape: "oval", widthMm: 100, depthMm: 40, source: "product-base-list: 40x100mm oval" },
  roach: { shape: "round", widthMm: 50, depthMm: 50, source: "product-base-list: 50mm" },
  "corpser-roach": { shape: "round", widthMm: 50, depthMm: 50, source: "product-base-list: roach family 50mm" },
  "vile-roach": { shape: "round", widthMm: 50, depthMm: 50, source: "product-base-list: roach family 50mm" },
  roachling: { shape: "round", widthMm: 32, depthMm: 32, source: "product-base-list: roachling 32mm" },
  marauder: { shape: "round", widthMm: 50, depthMm: 50, source: "starter/product-base-list: 50mm" },
  queen: { shape: "round", widthMm: 80, depthMm: 80, source: "starter/product-base-list: 80mm" },
  "omega-worm": { shape: "round", widthMm: 80, depthMm: 80, source: "starter/product-base-list: 80mm" },
  goliath: { shape: "round", widthMm: 80, depthMm: 80, source: "product-base-list: 80mm" },
  pylon: { shape: "round", widthMm: 80, depthMm: 80, source: "product-base-list: 80mm" },
};

function unitKey(unitOrName) {
  const name = typeof unitOrName === "string" ? unitOrName : unitOrName?.name || "";
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function baseRadiusInDirection(piece, angleRadians) {
  const width = Number(piece.baseWidthInches || (piece.baseMm ? piece.baseMm / MM_PER_INCH : 32 / MM_PER_INCH));
  const depth = Number(piece.baseDepthInches || width);
  const rx = Math.max(0.01, width / 2);
  const ry = Math.max(0.01, depth / 2);
  if (Math.abs(rx - ry) < 0.001) return rx;
  const cos = Math.cos(angleRadians);
  const sin = Math.sin(angleRadians);
  return 1 / Math.sqrt((cos * cos) / (rx * rx) + (sin * sin) / (ry * ry));
}

export function baseEdgeDistance(a, b) {
  const center = distance(a, b);
  if (center <= 0.0001) return -baseRadiusInDirection(a, 0) - baseRadiusInDirection(b, Math.PI);
  const angle = Math.atan2(Number(b.yInches || 0) - Number(a.yInches || 0), Number(b.xInches || 0) - Number(a.xInches || 0));
  return round(center - baseRadiusInDirection(a, angle) - baseRadiusInDirection(b, angle + Math.PI), 3);
}

export function basesOverlap(a, b) {
  return baseEdgeDistance(a, b) < -0.01;
}

function hasBaseOverlapAt(state, movingPiece, destination) {
  const candidate = { ...movingPiece, ...destination, isOnField: true };
  return activePieces(state, movingPiece.sideKey)
    .concat(enemyPieces(state, movingPiece.sideKey))
    .filter((piece) => piece.id !== movingPiece.id)
    .some((piece) => basesOverlap(candidate, piece));
}

function contactDestination(piece, target, engagementRangeInches = 0) {
  const centerDistance = distance(piece, target);
  if (centerDistance <= 0.001) return { xInches: piece.xInches, yInches: piece.yInches };
  const angle = Math.atan2(target.yInches - piece.yInches, target.xInches - piece.xInches);
  const stopCenterDistance = baseRadiusInDirection(piece, angle) + baseRadiusInDirection(target, angle + Math.PI) + Math.max(0, engagementRangeInches);
  const travelCenterDistance = Math.max(0, centerDistance - stopCenterDistance);
  const ratio = travelCenterDistance / centerDistance;
  return {
    xInches: round(piece.xInches + (target.xInches - piece.xInches) * ratio, 2),
    yInches: round(piece.yInches + (target.yInches - piece.yInches) * ratio, 2),
  };
}

function pointInRect(point, rect) {
  const halfW = Number(rect.widthInches || 0) / 2;
  const halfH = Number(rect.heightInches || 0) / 2;
  return point.x >= Number(rect.xInches || 0) - halfW
    && point.x <= Number(rect.xInches || 0) + halfW
    && point.y >= Number(rect.yInches || 0) - halfH
    && point.y <= Number(rect.yInches || 0) + halfH;
}

function segmentIntersectsRect(a, b, rect) {
  const minX = Number(rect.xInches || 0) - Number(rect.widthInches || 0) / 2;
  const maxX = Number(rect.xInches || 0) + Number(rect.widthInches || 0) / 2;
  const minY = Number(rect.yInches || 0) - Number(rect.heightInches || 0) / 2;
  const maxY = Number(rect.yInches || 0) + Number(rect.heightInches || 0) / 2;
  if (pointInRect(a, rect) || pointInRect(b, rect)) return true;
  let t0 = 0;
  let t1 = 1;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  for (const [p, q] of [[-dx, a.x - minX], [dx, maxX - a.x], [-dy, a.y - minY], [dy, maxY - a.y]]) {
    if (p === 0 && q < 0) return false;
    if (p !== 0) {
      const r = q / p;
      if (p < 0) t0 = Math.max(t0, r);
      else t1 = Math.min(t1, r);
      if (t0 > t1) return false;
    }
  }
  return true;
}

function segmentIntersectsCircle(a, b, circle) {
  const cx = Number(circle.xInches || 0);
  const cy = Number(circle.yInches || 0);
  const radius = Math.max(Number(circle.widthInches || 0), Number(circle.heightInches || 0)) / 2;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const lengthSq = dx * dx + dy * dy || 1;
  const t = clamp(((cx - a.x) * dx + (cy - a.y) * dy) / lengthSq, 0, 1);
  const closest = { x: a.x + t * dx, y: a.y + t * dy };
  return Math.hypot(closest.x - cx, closest.y - cy) <= radius;
}

function segmentIntersectsTerrain(a, b, terrain) {
  return terrain.footprint === "circle" ? segmentIntersectsCircle(a, b, terrain) : segmentIntersectsRect(a, b, terrain);
}

function pieceHeightTier(piece) {
  if (piece.heightTier != null) return Number(piece.heightTier);
  const size = parseExpectedValue(piece.stats?.size);
  if (size >= 4) return 3;
  if (size >= 2) return 2;
  return 1;
}

function activeTerrain(state) {
  return (state.board?.terrain || []).filter((terrain) => !terrain.isRemoved && !terrain.isDestroyed);
}

export function createStarcraftTmgTerrainPiece(kind, options = {}) {
  const defaults = TERRAIN_TRAIT_DEFAULTS[kind] || TERRAIN_TRAIT_DEFAULTS["mineral-field"];
  return {
    schemaVersion: "starcraft_tmg_terrain_piece_v0",
    id: options.id || `terrain-${kind}-${Math.random().toString(36).slice(2, 8)}`,
    terrainId: kind,
    ...defaults,
    ...options,
    xInches: Number(options.xInches ?? defaults.xInches ?? 0),
    yInches: Number(options.yInches ?? defaults.yInches ?? 0),
    widthInches: Number(options.widthInches ?? defaults.widthInches ?? 3),
    heightInches: Number(options.heightInches ?? defaults.heightInches ?? 2),
    rotationDegrees: Number(options.rotationDegrees || 0),
  };
}

export function buildStarcraftTmgScenarioMapCatalog(data = {}) {
  return {
    schemaVersion: "starcraft_tmg_scenario_map_catalog_v0",
    boardSizes: {
      standard: data.board?.standard || OFFICIAL_BOARD_SIZES.standard,
      skirmish: data.board?.skirmish || OFFICIAL_BOARD_SIZES.skirmish,
    },
    scenarioMaps: data.scenarioMaps || [],
    terrainCatalog: data.terrainCatalog || Object.entries(TERRAIN_TRAIT_DEFAULTS).map(([id, value]) => ({ id, terrainId: id, ...value })),
  };
}

export function classifyStarcraftTmgMissionScoring(card = {}) {
  const text = `${card.name || ""} ${card.missionParams || ""} ${card.scoringConditions || ""} ${card.additionalConditions || ""}`.toLowerCase();
  const families = [];
  if (/marker|objective|point|control/.test(text)) families.push("control_marker");
  if (/destroy|destroyed|kill|casualt/.test(text)) families.push("destroyed_supply");
  if (/round|turn|game length/.test(text)) families.push("round_timing");
  if (/deactivate|activate/.test(text)) families.push("active_marker");
  if (/quarter|zone|area/.test(text)) families.push("area_control");
  return {
    schemaVersion: "starcraft_tmg_mission_scoring_classifier_v0",
    cardId: card.id || "",
    name: card.name || "",
    families: families.length ? families : ["review_required"],
    executableFamilies: families.filter((family) => ["control_marker", "destroyed_supply", "round_timing"].includes(family)),
    reviewFragments: families.some((family) => ["active_marker", "area_control"].includes(family)) ? [text.slice(0, 220)] : [],
  };
}

export function evaluateStarcraftTmgLineOfSight(inputState, sourceId, targetId) {
  const state = normalizeStarcraftTmgState(inputState);
  const source = findPiece(state, sourceId);
  const target = findPiece(state, targetId);
  if (!source || !target) {
    return { schemaVersion: "starcraft_tmg_los_v0", hasLineOfSight: false, reason: "source_or_target_missing", blockers: [], cover: [] };
  }
  const a = { x: Number(source.xInches || 0), y: Number(source.yInches || 0) };
  const b = { x: Number(target.xInches || 0), y: Number(target.yInches || 0) };
  const sourceHeightTier = pieceHeightTier(source);
  const targetHeightTier = pieceHeightTier(target);
  const requiredBlockTier = Math.min(sourceHeightTier, targetHeightTier);
  const blockers = [];
  const cover = [];
  for (const terrain of activeTerrain(state)) {
    if (!segmentIntersectsTerrain(a, b, terrain)) continue;
    const row = {
      terrainId: terrain.id,
      terrainType: terrain.terrainId || terrain.id,
      name: terrain.name,
      heightTier: Number(terrain.heightTier || 0),
      category: terrain.category || "",
    };
    if (terrain.blocksLos && Number(terrain.heightTier || 0) >= requiredBlockTier) blockers.push(row);
    else if (terrain.providesCover) cover.push(row);
  }
  return {
    schemaVersion: "starcraft_tmg_los_v0",
    sourceId,
    targetId,
    hasLineOfSight: blockers.length === 0,
    sourceHeightTier,
    targetHeightTier,
    blockers,
    cover,
    sourceRule: "base_to_base_segment_with_height_tier_v0",
  };
}

export function evaluateStarcraftTmgTerrainPath(inputState, sourceId, destination = {}) {
  const state = normalizeStarcraftTmgState(inputState);
  const source = findPiece(state, sourceId);
  if (!source) return { schemaVersion: "starcraft_tmg_terrain_path_v0", blocked: true, reason: "source_missing", terrainCrossings: [] };
  const a = { x: Number(source.xInches || 0), y: Number(source.yInches || 0) };
  const b = { x: Number(destination.xInches ?? source.xInches), y: Number(destination.yInches ?? source.yInches) };
  const baseDistanceInches = Math.hypot(b.x - a.x, b.y - a.y);
  const terrainCrossings = [];
  let extraCostInches = 0;
  let blocked = false;
  let hazardDamage = 0;
  for (const terrain of activeTerrain(state)) {
    if (!segmentIntersectsTerrain(a, b, terrain)) continue;
    const crossing = {
      terrainId: terrain.id,
      terrainType: terrain.terrainId || terrain.id,
      name: terrain.name,
      difficult: Boolean(terrain.difficult),
      impassable: Boolean(terrain.impassable),
      hazard: Boolean(terrain.hazard),
      extraCostInches: terrain.difficult ? 2 : 0,
      hazardDamage: terrain.hazard ? Number(terrain.hazardDamage || 1) : 0,
    };
    if (crossing.impassable) blocked = true;
    extraCostInches += crossing.extraCostInches;
    hazardDamage += crossing.hazardDamage;
    terrainCrossings.push(crossing);
  }
  return {
    schemaVersion: "starcraft_tmg_terrain_path_v0",
    sourceId,
    destination: { xInches: round(b.x, 2), yInches: round(b.y, 2) },
    baseDistanceInches: round(baseDistanceInches, 2),
    extraCostInches: round(extraCostInches, 2),
    totalCostInches: round(baseDistanceInches + extraCostInches, 2),
    blocked,
    terrainCrossings,
    hazardDamage,
  };
}

function weaponKind(weapon) {
  return parseRange(weapon?.range) <= 1 ? "melee" : "ranged";
}

function weaponsForPhase(piece, phase) {
  return (piece.weapons || []).filter((weapon) => {
    const kind = weaponKind(weapon);
    if (phase === "assault") return kind === "ranged";
    if (phase === "combat") return kind === "melee";
    if (phase === "charge") return kind === "melee";
    return true;
  });
}

function bestWeaponForPhase(piece, phase, target) {
  return weaponsForPhase(piece, phase)
    .filter((weapon) => hasTargetMatch(weapon, target))
    .sort((a, b) => parseExpectedValue(b.dmg) * parseExpectedValue(b.roa) - parseExpectedValue(a.dmg) * parseExpectedValue(a.roa))[0] || null;
}

function profileForSize(unit, size = "small") {
  if (size === "large" && unit.largeProfile?.models) return unit.largeProfile;
  return unit.smallProfile?.models ? unit.smallProfile : unit.largeProfile || unit.smallProfile || { size, models: 1, supply: 1, cost: 0 };
}

function baseMmForUnit(unit) {
  const override = BASE_FOOTPRINT_OVERRIDES[unitKey(unit)];
  if (override) return Math.max(override.widthMm, override.depthMm);
  const size = parseExpectedValue(unit.stats?.size);
  if (size >= 4) return 60;
  if (size >= 3) return 50;
  if (size >= 2) return 40;
  return 32;
}

function baseFootprintForUnit(unit) {
  const override = BASE_FOOTPRINT_OVERRIDES[unitKey(unit)];
  const fallbackMm = baseMmForUnit(unit);
  const footprint = override || { shape: "round", widthMm: fallbackMm, depthMm: fallbackMm, source: "size-derived fallback" };
  return {
    shape: footprint.shape,
    widthMm: footprint.widthMm,
    depthMm: footprint.depthMm,
    widthInches: footprint.widthMm / MM_PER_INCH,
    depthInches: footprint.depthMm / MM_PER_INCH,
    source: footprint.source,
  };
}

function unitByName(data, name) {
  return data.units.find((unit) => unit.name === name) || null;
}

function unitById(data, id) {
  return data.units.find((unit) => unit.id === id) || null;
}

function visualForUnit(data, unitId) {
  return data.assetManifest?.unitVisuals?.find((visual) => visual.unitId === unitId) || {};
}

function sampleCardResourceRows(data, faction) {
  return (data.cards || [])
    .filter((card) => card.faction === faction && (Number(card.resource || 0) > 0 || (card.abilities || []).some((ability) => ability.kind === "reaction")))
    .slice(0, 3)
    .map((card, index) => materializeCardResource(card, index));
}

function selectedUpgradeRows(unit, selectedUpgradeNames = [], selectedUpgradeIndexes = []) {
  const selectedNames = new Set((selectedUpgradeNames || []).map((name) => String(name).toLowerCase()));
  const selectedIndexes = new Set((selectedUpgradeIndexes || []).map((index) => Number(index)));
  return (unit.upgrades || []).filter((upgrade, index) => {
    const isBase = Number(upgrade.costS || 0) === 0 && Number(upgrade.costL || 0) === 0;
    return isBase || selectedIndexes.has(index) || selectedNames.has(String(upgrade.name || "").toLowerCase());
  });
}

function normalizeAbilityId(name, index) {
  return String(name || `ability-${index}`).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || `ability-${index}`;
}

function abilityKindForUpgrade(upgrade = {}) {
  const text = `${upgrade.activation || ""} ${upgrade.description || ""}`.toLowerCase();
  if (text.includes("<active>")) return "active";
  if (text.includes("<reaction>")) return "reaction";
  if (text.includes("<passive>")) return "passive";
  return null;
}

function parseAbilityResourceCost(activation = "") {
  const match = String(activation || "").match(/\((\d+)\s+([^)]+)\)/i);
  if (!match) return null;
  const label = match[2].trim();
  const normalized = label.toLowerCase();
  const type = normalized.includes("command") ? "CP" : normalized.includes("biomass") ? "BM" : normalized.includes("psionic") ? "PE" : label.toUpperCase();
  return { amount: Number(match[1] || 0), type, label };
}

function classifyAbilityEffect(upgrade = {}) {
  const text = `${upgrade.name || ""} ${upgrade.description || ""}`.trim();
  const rangeMatch = text.match(/(?:WITHIN|WHOLLY WITHIN)\s+(\d+(?:\.\d+)?)\s*"?/i);
  const placeMatch = text.match(/PLACE\s*\((\d+(?:\.\d+)?)\)/i);
  const rangeInches = rangeMatch ? Number(rangeMatch[1]) : undefined;
  const placeInches = placeMatch ? Number(placeMatch[1]) : undefined;
  if (/SHADE\s+TOKEN/i.test(text)) return { effectKind: "marker", rangeInches: rangeInches || 12, markerLabel: "Shade", markerRadiusInches: 0.6, markerAuraInches: /WITHIN\s+4/i.test(text) ? 4 : undefined, keywords: ["DISPLACEMENT"], executable: true };
  if (/CREEP\s+TUMOR\s+TOKEN/i.test(text)) return { effectKind: "marker", rangeInches: rangeInches || 1, markerLabel: "Creep Tumor", markerRadiusInches: 0.8, keywords: [], executable: true };
  if (/FORCE\s+FIELD\s+TOKEN/i.test(text)) return { effectKind: "marker", rangeInches: rangeInches || 8, markerLabel: "Force Field", markerRadiusInches: 1, keywords: [], executable: true };
  const isBurrowStatusAbility = (/^Burrow$/i.test(String(upgrade.name || "").trim()) || /BURROWED\s+STATUS/i.test(text) || /gains\s+or\s+loses\s+the\s+Burrowed\s+Status/i.test(text)) && !/cannot gain burrowed/i.test(text);
  if (isBurrowStatusAbility) return { effectKind: "status", statusName: "BURROWED", keywords: ["BURROWED"], executable: true };
  if (/HIDDEN\s+STATUS/i.test(text)) return { effectKind: "status", statusName: "HIDDEN", keywords: ["HIDDEN"], executable: true };
  if (placeInches != null) return { effectKind: "place", rangeInches: placeInches, placeInches, keywords: [], executable: true };
  return { effectKind: "text", rangeInches, keywords: [], executable: false };
}

function abilitiesFromUpgrades(upgrades = []) {
  return (upgrades || []).map((upgrade, index) => {
    const kind = abilityKindForUpgrade(upgrade);
    if (!kind) return null;
    return {
      id: normalizeAbilityId(upgrade.name, index),
      name: upgrade.name || "",
      description: upgrade.description || "",
      phase: upgrade.phase || "Any Phase",
      activation: upgrade.activation || "",
      kind,
      resourceCost: upgrade.resourceCost || parseAbilityResourceCost(upgrade.activation),
      ...classifyAbilityEffect(upgrade),
    };
  }).filter(Boolean);
}

function battleAbilitiesForPiece(piece = {}) {
  if (Array.isArray(piece.abilities) && piece.abilities.length) return piece.abilities;
  const selected = Array.isArray(piece.selectedUpgrades) && piece.selectedUpgrades.length ? piece.selectedUpgrades : piece.upgrades || [];
  return abilitiesFromUpgrades(selected);
}

function pieceKeywordText(piece = {}) {
  return [piece.keywords, piece.tags, ...(piece.statuses || [])].filter(Boolean).join(" ");
}

function maxRegexNumber(text, patterns) {
  let best = 0;
  for (const pattern of patterns) {
    const flags = pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`;
    const matcher = new RegExp(pattern.source, flags);
    for (const match of String(text || "").matchAll(matcher)) {
      const raw = match.slice(1).find(Boolean);
      if (raw != null) best = Math.max(best, Number(raw) || 0);
    }
  }
  return best;
}

function regexNumbers(text, pattern) {
  const flags = pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`;
  const matcher = new RegExp(pattern.source, flags);
  return Array.from(String(text || "").matchAll(matcher))
    .map((match) => Number(match.slice(1).find(Boolean) || 0))
    .filter((value) => Number.isFinite(value) && value > 0);
}

function pieceIsOnCreep(state = {}, piece = {}) {
  return (state.board?.effectMarkers || []).some((marker) => {
    const label = `${marker.label || ""} ${marker.name || ""}`.toUpperCase();
    if (!label.includes("CREEP")) return false;
    const radius = Number(marker.auraInches ?? marker.radiusInches ?? 0.8);
    return distance(piece, marker) <= radius + 0.01;
  });
}

function buffSpeedDeltaForContext(text, state, piece) {
  const values = regexNumbers(text, /BUFF\s+SPEED\s*\((\d+(?:\.\d+)?)\)/i);
  if (!values.length) return 0;
  if (values.length > 1 && /\bON\s+CREEP\b/i.test(text)) {
    return pieceIsOnCreep(state, piece) ? Math.max(...values) : Math.min(...values);
  }
  return Math.max(...values);
}

function textAbilityHasAdvisoryEffect(text = "") {
  const upper = String(text || "").toUpperCase();
  return /BUFF\s+SPEED\s*\(/i.test(upper)
    || /BUFF\s+RANGE\s*\(/i.test(upper)
    || /(?:ADD|ADDS)\s+\d+(?:\.\d+)?[^.]{0,80}CHARGE\s+DISTANCE/i.test(upper)
    || /CHARGE\s+DISTANCE[^.]{0,80}(?:ADD|ADDS)\s+\d+(?:\.\d+)?/i.test(upper)
    || /PERFORMS?\s+A\s+\d+(?:\.\d+)?\s*"?\s+MOVE\s+ACTION/i.test(upper);
}

function effectiveWeaponRange(piece = {}, weapon = {}) {
  const baseRange = parseRange(weapon.range);
  const keywordText = `${weapon.keywords || ""} ${piece.keywords || ""}`.toUpperCase();
  const longRange = maxRegexNumber(keywordText, [/LONG\s*RANGE\s*(?:\((\d+(?:\.\d+)?)\s*"?\)|(\d+(?:\.\d+)?)\s*"?)/i]);
  const modifiers = [];
  if (longRange > baseRange) {
    modifiers.push({ sourceType: "weapon", sourceName: weapon.name || "Weapon", field: "range", deltaInches: round(longRange - baseRange, 2), note: `LONG RANGE extends this weapon from ${baseRange}" to ${longRange}".` });
  }
  return { rangeInches: Math.max(baseRange, longRange || 0), modifiers };
}

function threatProfileForPiece(state, piece) {
  const baseSpeed = parseSpeed(piece.stats?.speed);
  const statuses = new Set((piece.statuses || []).map((status) => String(status).toUpperCase()));
  let effectiveSpeed = baseSpeed;
  let rangeBonus = 0;
  let chargeBonus = 0;
  let setupExtension = 0;
  let meleeReach = Math.max(0.1, ...weaponsForPhase(piece, "combat").map((weapon) => parseRange(weapon.range)));
  const modifiers = [];

  if (statuses.has("PINNED") || statuses.has("STUNNED")) {
    modifiers.push({ sourceType: "status", sourceName: statuses.has("PINNED") ? "PINNED" : "STUNNED", field: "speed", deltaInches: -effectiveSpeed, note: "Status blocks normal movement threat until cleared." });
    effectiveSpeed = 0;
  }
  if (statuses.has("BURROWED")) modifiers.push({ sourceType: "status", sourceName: "BURROWED", field: "targeting", note: "Burrowed state is carried into threat notes; PLACE effects are evaluated when selected and resourced." });
  if (statuses.has("HIDDEN")) modifiers.push({ sourceType: "status", sourceName: "HIDDEN", field: "targeting", note: "Hidden is included in combat expectation as an Evade-granting target state." });

  const selected = Array.isArray(piece.selectedUpgrades) && piece.selectedUpgrades.length ? piece.selectedUpgrades : piece.upgrades || [];
  for (const ability of battleAbilitiesForPiece(piece)) {
    const text = `${ability.name || ""} ${ability.activation || ""} ${ability.description || ""}`.toUpperCase();
    const sourceName = ability.name || "Ability";
    const resourceOk = abilityResourceEnabled(state, piece.sideKey, ability);
    const textAdvisory = ability.effectKind === "text" && textAbilityHasAdvisoryEffect(text);
    const applies = !textAdvisory && (ability.kind !== "active" || resourceOk);
    const resourceNote = ability.resourceCost && !resourceOk ? ` Requires ${ability.resourceCost.amount} ${ability.resourceCost.type}, currently unavailable.` : "";
    const speedDelta = Math.max(
      maxRegexNumber(text, [/\+\s*(\d+(?:\.\d+)?)\s*"?\s*SPEED/i, /SPEED[^.]{0,30}\+\s*(\d+(?:\.\d+)?)/i, /MOVE(?:MENT)?[^.]{0,30}\+\s*(\d+(?:\.\d+)?)/i]),
      buffSpeedDeltaForContext(text, state, piece),
    );
    if (speedDelta) {
      if (applies) effectiveSpeed += speedDelta;
      modifiers.push({
        sourceType: "ability",
        sourceName,
        field: "speed",
        deltaInches: speedDelta,
        advisory: textAdvisory,
        note: textAdvisory
          ? `Ability text may add ${speedDelta}" Speed; display-only until a player confirms the exact timing/condition.${resourceNote}`
          : `Ability text adds ${speedDelta}" to movement threat.${resourceNote}`,
      });
    }
    const place = maxRegexNumber(text, [/PLACE\s*\((\d+(?:\.\d+)?)\)/i]);
    if (place && applies) {
      setupExtension = Math.max(setupExtension, place);
      modifiers.push({ sourceType: "ability", sourceName, field: "mobility", deltaInches: place, note: `PLACE(${place}) can extend setup and threat positioning.${resourceNote}` });
    }
    const extraMove = maxRegexNumber(text, [/PERFORMS?\s+A\s+(\d+(?:\.\d+)?)\s*"?\s+MOVE\s+ACTION/i]);
    if (extraMove) {
      if (applies) setupExtension = Math.max(setupExtension, extraMove);
      modifiers.push({
        sourceType: "ability",
        sourceName,
        field: "mobility",
        deltaInches: extraMove,
        advisory: textAdvisory,
        note: textAdvisory
          ? `Ability text may grant an extra ${extraMove}" move action; display-only until a player confirms the exact timing/condition.${resourceNote}`
          : `Extra ${extraMove}" move action can extend setup and threat positioning.${resourceNote}`,
      });
    }
    const range = maxRegexNumber(text, [/\+\s*(\d+(?:\.\d+)?)\s*"?\s*RANGE/i, /RANGE[^.]{0,30}\+\s*(\d+(?:\.\d+)?)/i, /BUFF\s+RANGE\s*\((\d+(?:\.\d+)?)\)/i]);
    if (range) {
      if (applies) rangeBonus = Math.max(rangeBonus, range);
      modifiers.push({
        sourceType: "ability",
        sourceName,
        field: "range",
        deltaInches: range,
        advisory: textAdvisory,
        note: textAdvisory
          ? `Ability text may extend ranged threat by ${range}"; display-only until a player confirms the exact timing/condition.${resourceNote}`
          : `Ability text extends ranged threat by ${range}".${resourceNote}`,
      });
    }
    const melee = maxRegexNumber(text, [/(?:MELEE|ENGAGEMENT|REACH)[^.]{0,30}(\d+(?:\.\d+)?)\s*"?/i, /(\d+(?:\.\d+)?)\s*"?\s*(?:MELEE|ENGAGEMENT|REACH)/i]);
    if (melee && applies) {
      meleeReach = Math.max(meleeReach, melee);
      modifiers.push({ sourceType: "ability", sourceName, field: "melee", deltaInches: melee, note: `Ability text sets/extends melee reach to ${melee}".${resourceNote}` });
    }
    const charge = maxRegexNumber(text, [/\+\s*(\d+(?:\.\d+)?)\s*(?:DICE|DIE|")?\s*(?:TO\s*)?CHARGE/i, /CHARGE[^.]{0,30}\+\s*(\d+(?:\.\d+)?)/i, /(?:ADD|ADDS)\s+(\d+(?:\.\d+)?)[^.]{0,80}CHARGE\s+DISTANCE/i, /CHARGE\s+DISTANCE[^.]{0,80}(?:ADD|ADDS)\s+(\d+(?:\.\d+)?)/i]);
    if (charge) {
      if (applies) chargeBonus = Math.max(chargeBonus, charge);
      modifiers.push({
        sourceType: "ability",
        sourceName,
        field: "charge",
        deltaInches: charge,
        advisory: textAdvisory,
        note: textAdvisory
          ? `Ability text may improve charge reach/probability by ${charge}"; display-only until a player confirms the exact timing/condition.${resourceNote}`
          : `Ability text improves charge reach/probability by ${charge}".${resourceNote}`,
      });
    }
    if (ability.resourceCost && !resourceOk) modifiers.push({
      sourceType: "resource",
      sourceName,
      field: "mobility",
      advisory: textAdvisory,
      note: textAdvisory
        ? `Resource requirement for ${sourceName} is shown for player review; it does not hard-limit movement or action legality.`
        : `Threat effect from ${sourceName} is withheld because ${ability.resourceCost.type} is insufficient.`,
    });
  }
  for (const upgrade of selected) {
    const text = `${upgrade.name || ""} ${upgrade.activation || ""} ${upgrade.description || ""}`.toUpperCase();
    const range = maxRegexNumber(text, [/\+\s*(\d+(?:\.\d+)?)\s*"?\s*RANGE/i, /RANGE[^.]{0,30}\+\s*(\d+(?:\.\d+)?)/i]);
    if (range) {
      modifiers.push({ sourceType: "upgrade", sourceName: upgrade.name || "Upgrade", field: "range", deltaInches: range, advisory: true, note: `Selected upgrade may extend ranged threat by ${range}"; display-only until a player confirms the exact timing/condition.` });
    }
  }
  for (const weapon of piece.weapons || []) modifiers.push(...effectiveWeaponRange(piece, weapon).modifiers);
  const bestRanged = weaponsForPhase(piece, "assault").reduce((max, weapon) => Math.max(max, effectiveWeaponRange(piece, weapon).rangeInches), 0);
  const rangedThreat = bestRanged + rangeBonus;
  const chargeDiceMax = Math.max(0, 6 + chargeBonus);
  const chargeDiceAverage = Math.max(0, 3.5 + chargeBonus);
  const moveShootThreat = effectiveSpeed + setupExtension + rangedThreat;
  const moveChargeMeleeThreat = effectiveSpeed + setupExtension + chargeDiceMax + meleeReach;
  const chargeProbabilityBands = [
    { label: "Charge 83%+", probability: 0.83, minDistanceInches: 0, maxDistanceInches: round(effectiveSpeed + setupExtension + meleeReach + chargeBonus + 2, 2) },
    { label: "Charge 50%+", probability: 0.5, minDistanceInches: round(effectiveSpeed + setupExtension + meleeReach + chargeBonus + 2, 2), maxDistanceInches: round(effectiveSpeed + setupExtension + meleeReach + chargeBonus + 4, 2) },
    { label: "Charge 17%+", probability: 0.17, minDistanceInches: round(effectiveSpeed + setupExtension + meleeReach + chargeBonus + 4, 2), maxDistanceInches: round(moveChargeMeleeThreat, 2) },
  ].filter((band) => band.maxDistanceInches > band.minDistanceInches + 0.01);
  return {
    baseSpeed,
    effectiveSpeed,
    bestRanged,
    bestRange: Math.max(rangedThreat, meleeReach),
    baseThreat: Math.max(rangedThreat, meleeReach),
    setupThreat: Math.max(moveShootThreat, moveChargeMeleeThreat),
    moveShootThreat,
    moveChargeMeleeThreat,
    meleeReach,
    setupExtension,
    chargeDiceBonus: chargeBonus,
    chargeDiceMax,
    chargeDiceAverage,
    chargeProbabilityBands,
    modifiers,
  };
}

function chargeSuccessProbability(requiredDistanceInches, profile) {
  const remaining = Number(requiredDistanceInches || 0) - profile.effectiveSpeed - profile.setupExtension;
  if (remaining <= 0.01) return 1;
  const neededNatural = Math.ceil(remaining - profile.chargeDiceBonus);
  if (neededNatural <= 1) return 1;
  if (neededNatural > 6) return 0;
  return round((7 - neededNatural) / 6, 3);
}

function cardByIdOrName(data, idOrName) {
  const key = String(idOrName || "").toLowerCase();
  return data.cards?.find((card) => String(card.id).toLowerCase() === key || String(card.name).toLowerCase() === key) || null;
}

function materializeCardResource(card, index = 0) {
  const maxResource = Math.max(0, Number(card.resource || 0));
  return {
    id: `card-resource-${card.id || index}`,
    cardId: card.id || "",
    name: card.name || "",
    faction: card.faction || "",
    isFactionCard: Boolean(card.isFactionCard),
    resourceType: card.resourceType || "",
    maxResource,
    currentResource: maxResource,
    usedThisRound: false,
    abilities: card.abilities || [],
    boosts: card.boosts || [],
  };
}

function emptySlots() {
  return { Core: 0, Elite: 0, Support: 0, Hero: 0, Air: 0, Other: 0 };
}

export function buildStarcraftTmgCardResources(data, roster = {}) {
  const ids = [
    roster.factionCardId,
    ...(roster.cardIds || []),
    ...(roster.tacticalCardIds || []),
    ...((roster.cards || []).map((card) => card.cardId || card.id || card.name)),
  ].filter(Boolean);
  const seen = new Set();
  return ids
    .map((id) => cardByIdOrName(data, id))
    .filter((card) => card && !seen.has(card.id) && seen.add(card.id))
    .filter((card) => Number(card.resource || 0) > 0 || (card.abilities || []).length > 0)
    .map((card, index) => materializeCardResource(card, index));
}

function materializePiece(data, unit, { sideKey, size = "small", xInches = 0, yInches = 0, onField = true, rosterIndex = 0, selectedUpgradeNames = [], selectedUpgradeIndexes = [] } = {}) {
  const profile = profileForSize(unit, size);
  const footprint = baseFootprintForUnit(unit);
  const visual = visualForUnit(data, unit.id);
  const selectedUpgrades = selectedUpgradeRows(unit, selectedUpgradeNames, selectedUpgradeIndexes);
  const selectedIndexes = new Set((selectedUpgradeIndexes || []).map((index) => Number(index)));
  const selectedNames = new Set((selectedUpgradeNames || []).map((name) => String(name).toLowerCase()));
  const selectedUpgradeCost = (unit.upgrades || []).reduce((sum, upgrade, index) => {
    if (!selectedIndexes.has(index) && !selectedNames.has(String(upgrade.name || "").toLowerCase())) return sum;
    return sum + (profile.size === "large" ? Number(upgrade.costL || 0) : Number(upgrade.costS || 0));
  }, 0);
  const weapons = selectedUpgrades.filter((upgrade) => upgrade.weapon).map((upgrade) => ({
    ...upgrade.weapon,
    sourceUpgradeName: upgrade.name,
  }));
  return {
    id: `${sideKey}-${unit.id}-${rosterIndex}`,
    sideKey,
    unitId: unit.id,
    name: unit.name,
    faction: unit.faction,
    unitType: unit.unitType,
    profileSize: profile.size,
    baseMm: Math.max(footprint.widthMm, footprint.depthMm),
    baseShape: footprint.shape,
    baseWidthMm: footprint.widthMm,
    baseDepthMm: footprint.depthMm,
    baseWidthInches: footprint.widthInches,
    baseDepthInches: footprint.depthInches,
    baseSource: footprint.source,
    xInches,
    yInches,
    maxModels: profile.models ?? 1,
    currentModels: profile.models ?? 1,
    supply: profile.supply ?? 1,
    cost: (profile.cost ?? 0) + selectedUpgradeCost,
    stats: unit.stats || {},
    tags: unit.tags || "",
    keywords: unit.keywords || "",
    weapons,
    abilities: abilitiesFromUpgrades(selectedUpgrades),
    upgrades: unit.upgrades || [],
    selectedUpgrades,
    selectedUpgradeNames: selectedUpgrades.map((upgrade) => upgrade.name),
    visual,
    isOnField: onField,
    isDestroyed: false,
    damageMarker: 0,
    destroyedThisRoundSupply: 0,
    statuses: [],
    activatedPhases: { movement: false, assault: false, combat: false },
    usedActiveAbilities: [],
    usedReactions: [],
  };
}

export async function loadStarcraftTmgData(root = process.cwd()) {
  const filePath = path.join(root, "starcraft-tmg-local", "data", "starcraft-tmg-data.json");
  return JSON.parse(await readFile(filePath, "utf8"));
}

export function buildStarcraftTmgRoster(data, roster, options = {}) {
  const sideKey = options.sideKey || "player1";
  const units = [];
  for (const [index, entry] of (roster?.units || []).entries()) {
    const unit = unitById(data, entry.unitId) || unitByName(data, entry.name);
    if (!unit) continue;
    units.push(materializePiece(data, unit, {
      sideKey,
      size: entry.size || "small",
      onField: Boolean(entry.onField),
      xInches: entry.xInches ?? (sideKey === "player1" ? 4 : (data.board?.standard?.widthInches || 54) - 4),
      yInches: entry.yInches ?? 9 + index * 3,
      rosterIndex: index,
      selectedUpgradeNames: entry.upgrades || entry.selectedUpgradeNames || [],
      selectedUpgradeIndexes: entry.upgradeIndexes || entry.selectedUpgradeIndexes || [],
    }));
  }
  return {
    schemaVersion: "starcraft_tmg_warband_v0",
    sideKey,
    faction: roster?.faction || units[0]?.faction || "Terran",
    pieces: units,
    cardResources: buildStarcraftTmgCardResources(data, roster),
    totalCost: units.reduce((sum, piece) => sum + piece.cost, 0),
    totalSupply: units.reduce((sum, piece) => sum + piece.supply, 0),
  };
}

function normalizeSlotKey(slot) {
  const key = Object.keys(emptySlots()).find((candidate) => candidate.toLowerCase() === String(slot || "").toLowerCase());
  return key || "Other";
}

function slotCostForProfile(profile = {}) {
  return Math.max(0, Number(profile.supply || 0));
}

function selectedUpgradeIndexesForEntry(unit, entry = {}) {
  const indexSet = new Set((entry.upgradeIndexes || entry.selectedUpgradeIndexes || []).map(Number));
  const nameSet = new Set((entry.upgrades || entry.selectedUpgradeNames || []).map((name) => String(name).toLowerCase()));
  for (const [index, upgrade] of (unit.upgrades || []).entries()) {
    if (nameSet.has(String(upgrade.name || "").toLowerCase())) indexSet.add(index);
  }
  return [...indexSet].filter((index) => Number.isFinite(index));
}

export function computeStarcraftTmgArmyState(data, roster = {}) {
  const mineralsLimit = Number(roster.mineralsLimit || 500);
  const gasLimit = Math.floor(mineralsLimit * 0.1);
  const slotsAvailable = emptySlots();
  const slotsUsed = emptySlots();
  const selectedCards = [
    roster.factionCardId,
    ...(roster.tacticalCardIds || []),
  ].filter(Boolean)
    .map((id) => cardByIdOrName(data, id))
    .filter(Boolean);

  let gasUsed = 0;
  let resourceTotal = 0;
  for (const card of selectedCards) {
    if (!card.isFactionCard) gasUsed += Number(card.cost || 0);
    resourceTotal += Number(card.resource || 0);
    for (const [slot, value] of Object.entries(card.slots || {})) {
      const key = normalizeSlotKey(slot);
      slotsAvailable[key] = (slotsAvailable[key] || 0) + Number(value || 0);
    }
  }

  let mineralsUsed = 0;
  let supplyUsed = 0;
  const unitRows = [];
  for (const entry of roster.units || roster.roster || []) {
    const unit = unitById(data, entry.unitId) || unitByName(data, entry.name);
    if (!unit) continue;
    const profile = profileForSize(unit, entry.size || "small");
    const upgradeIndexes = selectedUpgradeIndexesForEntry(unit, entry);
    let upgradeCostTotal = 0;
    const upgradeNames = [];
    for (const index of upgradeIndexes) {
      const upgrade = unit.upgrades?.[index];
      if (!upgrade) continue;
      upgradeCostTotal += profile.size === "large" ? Number(upgrade.costL || 0) : Number(upgrade.costS || 0);
      upgradeNames.push(upgrade.name);
    }
    const slot = normalizeSlotKey(unit.unitType);
    const slotCost = slotCostForProfile(profile);
    slotsUsed[slot] = (slotsUsed[slot] || 0) + slotCost;
    mineralsUsed += Number(profile.cost || 0) + upgradeCostTotal;
    supplyUsed += Number(profile.supply || 0);
    unitRows.push({
      unitId: unit.id,
      name: unit.name,
      unitType: unit.unitType,
      size: profile.size,
      baseCost: Number(profile.cost || 0),
      upgradeCost: upgradeCostTotal,
      minerals: Number(profile.cost || 0) + upgradeCostTotal,
      supply: Number(profile.supply || 0),
      slotCost,
      models: Number(profile.models || 1),
      upgradeIndexes,
      upgradeNames,
    });
  }

  return {
    schemaVersion: "starcraft_tmg_army_state_v0",
    mineralsUsed,
    mineralsLimit,
    gasUsed,
    gasLimit,
    resourceTotal,
    supplyUsed,
    slotsAvailable,
    slotsUsed,
    unitRows,
    missionId: roster.missionId || null,
    deploymentId: roster.deploymentId || null,
  };
}

export function validateStarcraftTmgRoster(data, roster = {}) {
  const errors = [];
  const warnings = [];
  const units = roster.units || [];
  const faction = roster.faction || null;
  const armyState = computeStarcraftTmgArmyState(data, roster);
  let cost = armyState.mineralsUsed;
  let gas = armyState.gasUsed;
  const slotsAvailable = armyState.slotsAvailable;
  const slotsUsed = armyState.slotsUsed;
  const selectedCards = buildStarcraftTmgCardResources(data, roster);
  for (const cardId of [roster.factionCardId, ...(roster.cardIds || []), ...(roster.tacticalCardIds || [])].filter(Boolean)) {
    const card = cardByIdOrName(data, cardId);
    if (!card) {
      errors.push({ code: "card_not_found", card: cardId });
      continue;
    }
    if (faction && card.faction !== faction) errors.push({ code: "card_faction_mismatch", card: card.name, expected: faction, actual: card.faction });
  }
  for (const entry of units) {
    const unit = unitById(data, entry.unitId) || unitByName(data, entry.name);
    if (!unit) {
      errors.push({ code: "unit_not_found", unit: entry.unitId || entry.name });
      continue;
    }
    if (faction && unit.faction !== faction) errors.push({ code: "faction_mismatch", unit: unit.name, expected: faction, actual: unit.faction });
  }
  const limit = Number(roster.mineralsLimit || 500);
  if (cost > limit) errors.push({ code: "minerals_limit_exceeded", cost, limit });
  const gasLimit = Math.floor(limit * 0.1);
  if (gas > gasLimit) errors.push({ code: "gas_limit_exceeded", gas, gasLimit });
  const hasSlotBudget = Boolean(roster.factionCardId || roster.cardIds?.length || roster.tacticalCardIds?.length || roster.cards?.length);
  for (const [slot, used] of Object.entries(slotsUsed)) {
    const available = Number(slotsAvailable[slot] || 0);
    if (hasSlotBudget && used > available) errors.push({ code: "slot_limit_exceeded", slot, used, available });
  }
  if (!roster.faction) warnings.push({ code: "faction_inferred", message: "Roster did not specify a faction." });
  return { ok: errors.length === 0, cost, limit, gas, gasLimit, slotsAvailable, slotsUsed, cardResources: selectedCards, errors, warnings };
}

export function exportStarcraftTmgArmyText(data, roster = {}) {
  const name = roster.name || `${roster.faction || "StarCraft"} Army`;
  const faction = roster.faction || "Terran";
  const lines = [`=== ${name} ===`, `Faction: ${faction}`, `Minerals: ${Number(roster.mineralsLimit || 500)}`, ""];
  const factionCard = cardByIdOrName(data, roster.factionCardId);
  if (factionCard) lines.push(`[FC] ${factionCard.name}`);
  const tacticalCounts = new Map();
  for (const id of roster.tacticalCardIds || []) tacticalCounts.set(id, (tacticalCounts.get(id) || 0) + 1);
  for (const [id, count] of tacticalCounts.entries()) {
    const card = cardByIdOrName(data, id);
    if (card) lines.push(`[TC] ${card.name}${count > 1 ? ` x${count}` : ""} (${Number(card.cost || 0) * count}gas)`);
  }
  const mission = data.officialMissions?.find((card) => card.id === roster.missionId) || data.gameCards?.find((card) => card.id === roster.missionId);
  if (mission) {
    const parts = [mission.name];
    if (mission.format) parts.push(mission.format);
    if (mission.gameLength) parts.push(`${mission.gameLength}R`);
    if (mission.startingSupply != null) parts.push(`${mission.startingSupply}S`);
    lines.push(`[Mission] ${parts.join(" · ")}`);
  }
  const deployment = data.officialDeployments?.find((card) => card.id === roster.deploymentId) || data.gameCards?.find((card) => card.id === roster.deploymentId);
  if (deployment) {
    const parts = [deployment.name];
    if (deployment.gameSize) parts.push(deployment.gameSize);
    lines.push(`[Deploy] ${parts.join(" · ")}`);
  }
  lines.push("", "--- Roster ---");
  const armyState = computeStarcraftTmgArmyState(data, roster);
  for (const [index, row] of armyState.unitRows.entries()) {
    let line = `${index + 1}. ${row.name} [${row.unitType}/${row.size}] ${row.baseCost}M`;
    if (row.upgradeNames.length) line += ` +upg: ${row.upgradeNames.join(", ")}`;
    lines.push(line);
  }
  lines.push("");
  lines.push(`Total: ${armyState.mineralsUsed}/${armyState.mineralsLimit}M ${armyState.gasUsed}/${armyState.gasLimit}G`);
  lines.push("=== END ===");
  return lines.join("\n");
}

function firstPart(text) {
  return String(text || "").split("·")[0].trim();
}

export function importStarcraftTmgArmyText(data, text = "") {
  const lines = String(text).split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  let name = "Imported Army";
  let faction = "Terran";
  let mineralsLimit = 500;
  let factionCardId = "";
  let missionId = "";
  let deploymentId = "";
  const tacticalCardIds = [];
  const units = [];

  for (const line of lines) {
    const nameMatch = line.match(/^===\s*(.+?)\s*===$/);
    if (nameMatch && nameMatch[1] !== "END") name = nameMatch[1];
    const factionMatch = line.match(/^(?:Faction|阵营):\s*(.+)$/);
    if (factionMatch) faction = factionMatch[1].trim();
    const mineralMatch = line.match(/^(?:Minerals|矿物上限):\s*(\d+)$/);
    if (mineralMatch) mineralsLimit = Number(mineralMatch[1]);
    const fcMatch = line.match(/^\[(?:FC|阵营卡)\]\s*(.+)$/);
    if (fcMatch) {
      const cardName = firstPart(fcMatch[1]);
      const card = data.cards?.find((item) => item.isFactionCard && item.faction === faction && item.name === cardName);
      if (card) factionCardId = card.id;
    }
    const tcMatch = line.match(/^\[(?:TC|战术卡)\]\s*(.+?)(?:\s*x(\d+))?\s*\(/);
    if (tcMatch) {
      const cardName = firstPart(tcMatch[1]);
      const count = Number(tcMatch[2] || 1);
      const card = data.cards?.find((item) => !item.isFactionCard && item.faction === faction && item.name === cardName);
      if (card) for (let index = 0; index < count; index += 1) tacticalCardIds.push(card.id);
    }
    const missionMatch = line.match(/^\[(?:Mission|任务)\]\s*(.+)$/);
    if (missionMatch) {
      const missionName = firstPart(missionMatch[1]);
      const mission = data.officialMissions?.find((item) => item.name === missionName) || data.gameCards?.find((item) => item.name === missionName);
      if (mission) missionId = mission.id;
    }
    const deploymentMatch = line.match(/^\[(?:Deploy|Deployment|部署)\]\s*(.+)$/);
    if (deploymentMatch) {
      const deploymentName = firstPart(deploymentMatch[1]);
      const deployment = data.officialDeployments?.find((item) => item.name === deploymentName) || data.gameCards?.find((item) => item.name === deploymentName);
      if (deployment) deploymentId = deployment.id;
    }
    const unitMatch = line.match(/^\d+\.\s*(.+?)\s*\[([^/\]]+)\/([^\]]+)\]\s*(\d+)(?:M|矿)/);
    if (unitMatch) {
      const [, unitName, , rawSize] = unitMatch;
      const unit = data.units?.find((item) => item.name === unitName && item.faction === faction);
      if (!unit) continue;
      const size = String(rawSize).toLowerCase() === "large" ? "large" : "small";
      const upgradeIndexes = [];
      const upgradeMatch = line.match(/\+(?:upg|升级):\s*(.+)$/i);
      if (upgradeMatch) {
        const names = upgradeMatch[1].split(",").map((item) => item.trim()).filter(Boolean);
        for (const upgradeName of names) {
          const index = (unit.upgrades || []).findIndex((upgrade) => upgrade.name === upgradeName);
          if (index >= 0) upgradeIndexes.push(index);
        }
      }
      units.push({ unitId: unit.id, name: unit.name, size, upgradeIndexes });
    }
  }

  const roster = {
    name,
    faction,
    mineralsLimit,
    factionCardId,
    tacticalCardIds,
    units,
    missionId,
    deploymentId,
  };
  return {
    schemaVersion: "starcraft_tmg_army_import_v0",
    roster,
    validation: validateStarcraftTmgRoster(data, roster),
  };
}

export function createStarcraftTmgSampleState(data) {
  const mission = data.officialMissions.find((card) => card.name === "Divide and Conquer") || data.officialMissions[0] || data.gameCards.find((card) => card.type === "mission");
  const deployment = data.officialDeployments.find((card) => card.name === "GAUNTLET") || data.officialDeployments[0] || data.gameCards.find((card) => card.type === "deployment");
  const scenarioMap = data.scenarioMaps?.find((map) => map.id === "lost-temple-standard") || data.scenarioMaps?.[0] || null;
  const boardSize = scenarioMap?.boardSize || data.board?.standard || OFFICIAL_BOARD_SIZES.standard;
  const p1Names = ["Marine", "Marauder", "Medic", "Goliath"];
  const p2Names = ["Zergling", "Roach", "Hydralisk", "Queen"];
  const pieces = [];
  p1Names.forEach((name, index) => {
    const unit = unitByName(data, name);
    if (unit) pieces.push(materializePiece(data, unit, { sideKey: "player1", rosterIndex: index, xInches: index < 2 ? 9 : 0, yInches: 14 + index * 3, onField: index < 2 }));
  });
  p2Names.forEach((name, index) => {
    const unit = unitByName(data, name);
    if (unit) pieces.push(materializePiece(data, unit, { sideKey: "player2", rosterIndex: index, xInches: index < 2 ? boardSize.widthInches - 9 : boardSize.widthInches, yInches: 14 + index * 3, onField: index < 2 }));
  });
  return normalizeStarcraftTmgState({
    schemaVersion: STARCRAFT_TMG_STATE_SCHEMA,
    gameId: "starcraft-tmg",
    dataVersion: data.version,
    round: 1,
    phase: "movement",
    activeSideKey: "player1",
    firstPlayerSideKey: "player1",
    board: {
      widthInches: boardSize.widthInches || 54,
      heightInches: boardSize.heightInches || 36,
      scenarioMapId: scenarioMap?.id || "",
      scenarioMapName: scenarioMap?.name || "",
      backgroundImageUrl: scenarioMap?.backgroundUrl || deployment?.frontUrl || "",
      deploymentId: deployment?.id,
      deploymentName: deployment?.name || "GAUNTLET",
      deploymentImageUrl: deployment?.frontUrl || "",
      mapSourceType: deployment?.type || "deployment",
      centerMarkers: scenarioMap?.objectives?.length ? scenarioMap.objectives : [{ id: "marker-5", xInches: (boardSize.widthInches || 54) / 2, yInches: (boardSize.heightInches || 36) / 2, radiusInches: 3, label: String(mission?.refId || 5) }],
      effectMarkers: [],
      terrain: (scenarioMap?.terrainDefaults || []).map((terrain) => createStarcraftTmgTerrainPiece(terrain.terrainId || terrain.id, terrain)),
    },
    mission: mission || null,
    scores: { player1: 0, player2: 0 },
    supplyDestroyedThisRound: { player1: 0, player2: 0 },
    players: {
      player1: { sideKey: "player1", name: "Player 1", faction: "Terran", passedPhases: {} },
      player2: { sideKey: "player2", name: "Player 2", faction: "Zerg", passedPhases: {} },
    },
    cardResources: {
      player1: sampleCardResourceRows(data, "Terran"),
      player2: sampleCardResourceRows(data, "Zerg"),
    },
    pieces,
    log: [],
    omittedRules: [
      "Exact mission text semantics are preserved but only central marker and destroyed-supply scoring are executable in v0.",
      "Exact deployment-zone geometry is not inferred from deployment-card images in v0; Project D scenario-map presets provide editable geometry.",
      "Long-form active/reaction abilities are parsed as text unless represented by combat keyword heuristics.",
    ],
  });
}

export function normalizeStarcraftTmgState(input = {}) {
  const state = deepClone(input);
  state.schemaVersion = state.schemaVersion || STARCRAFT_TMG_STATE_SCHEMA;
  state.round = Math.max(1, Number(state.round || 1));
  state.phase = PHASES.includes(state.phase) ? state.phase : "movement";
  state.activeSideKey = state.activeSideKey || "player1";
  state.firstPlayerSideKey = state.firstPlayerSideKey || "player1";
  state.scores = state.scores || { player1: 0, player2: 0 };
  state.supplyDestroyedThisRound = state.supplyDestroyedThisRound || { player1: 0, player2: 0 };
  state.scoringResolvedThisPhase = {
    player1: false,
    player2: false,
    ...(state.scoringResolvedThisPhase || {}),
  };
  state.gameOver = Boolean(state.gameOver);
  state.terminal = Boolean(state.terminal || state.gameOver);
  state.winner = state.winner || "";
  state.terminalReason = state.terminalReason || "";
  state.firstPassSideByPhase = state.firstPassSideByPhase || {};
  state.players = state.players || {
    player1: { sideKey: "player1", name: "Player 1", faction: "Terran", passedPhases: {} },
    player2: { sideKey: "player2", name: "Player 2", faction: "Zerg", passedPhases: {} },
  };
  state.board = {
    widthInches: 54,
    heightInches: 36,
    centerMarkers: [{ id: "marker-5", xInches: 27, yInches: 18, radiusInches: 3, label: "5" }],
    effectMarkers: [],
    terrain: [],
    ...(state.board || {}),
  };
  state.board.effectMarkers = state.board.effectMarkers || [];
  state.board.terrain = (state.board.terrain || []).map((terrain) => createStarcraftTmgTerrainPiece(terrain.terrainId || terrain.id, terrain));
  state.cardResources = {
    player1: [],
    player2: [],
    ...(state.cardResources || {}),
  };
  for (const sideKey of Object.keys(state.cardResources)) {
    state.cardResources[sideKey] = (state.cardResources[sideKey] || []).map((card, index) => ({
      id: card.id || `card-resource-${card.cardId || index}`,
      cardId: card.cardId || card.id || "",
      name: card.name || card.cardName || "",
      faction: card.faction || "",
      resourceType: card.resourceType || "",
      maxResource: Number(card.maxResource ?? card.resource ?? 0),
      currentResource: Number(card.currentResource ?? card.maxResource ?? card.resource ?? 0),
      usedThisRound: Boolean(card.usedThisRound),
      abilities: card.abilities || [],
      boosts: card.boosts || [],
      ...card,
    }));
  }
  state.pieces = (state.pieces || []).map((piece) => ({
    damageMarker: 0,
    statuses: [],
    activatedPhases: { movement: false, assault: false, combat: false },
    usedActiveAbilities: [],
    usedReactions: [],
    isOnField: true,
    isDestroyed: false,
    currentModels: piece.maxModels || 1,
    ...piece,
    selectedUpgrades: piece.selectedUpgrades || [],
    selectedUpgradeNames: piece.selectedUpgradeNames || [],
    abilities: piece.abilities || battleAbilitiesForPiece(piece),
  }));
  state.log = state.log || [];
  state.omittedRules = state.omittedRules || [];
  return state;
}

function otherSideKey(sideKey) {
  return sideKey === "player1" ? "player2" : "player1";
}

function scoringResolvedForSide(state, sideKey) {
  return Boolean(state.scoringResolvedThisPhase?.[sideKey]);
}

function allScoringSidesResolved(state) {
  return SIDE_KEYS.every((sideKey) => scoringResolvedForSide(state, sideKey));
}

function missionGameLength(state) {
  return Math.max(1, Number(state.mission?.gameLength || 4));
}

function markStarcraftTerminalIfNeeded(state, events = []) {
  if (state.gameOver || state.round <= missionGameLength(state)) return state;
  const p1 = Number(state.scores?.player1 || 0);
  const p2 = Number(state.scores?.player2 || 0);
  const winner = p1 === p2 ? "draw" : p1 > p2 ? "player1" : "player2";
  state.gameOver = true;
  state.terminal = true;
  state.winner = winner;
  state.terminalReason = `mission_game_length_${missionGameLength(state)}_complete`;
  events.push({ type: "game_end", winner, finalScore: { player1: p1, player2: p2 }, reason: state.terminalReason });
  return state;
}

function activePieces(state, sideKey = state.activeSideKey) {
  return state.pieces.filter((piece) => piece.sideKey === sideKey && piece.isOnField && !piece.isDestroyed && piece.currentModels > 0);
}

function enemyPieces(state, sideKey = state.activeSideKey) {
  return state.pieces.filter((piece) => piece.sideKey !== sideKey && piece.isOnField && !piece.isDestroyed && piece.currentModels > 0);
}

function reservePieces(state, sideKey = state.activeSideKey) {
  return state.pieces.filter((piece) => piece.sideKey === sideKey && !piece.isOnField && !piece.isDestroyed && piece.currentModels > 0);
}

function activated(piece, phase) {
  return Boolean(piece.activatedPhases?.[phase]);
}

function abilityMatchesPhase(ability, phase) {
  const text = `${ability.phase || ""} ${ability.activation || ""}`.toLowerCase();
  return !text || text.includes("any phase") || text.includes(phase);
}

function sideResourceAvailable(state, sideKey, type) {
  if (!type) return 0;
  return (state.cardResources?.[sideKey] || [])
    .filter((card) => String(card.resourceType || "").toUpperCase() === String(type).toUpperCase())
    .reduce((sum, card) => sum + Number(card.currentResource || 0), 0);
}

function abilityResourceEnabled(state, sideKey, ability) {
  if (!ability.resourceCost || Number(ability.resourceCost.amount || 0) <= 0) return true;
  return sideResourceAvailable(state, sideKey, ability.resourceCost.type) >= Number(ability.resourceCost.amount || 0);
}

function abilityDestination(state, piece, ability) {
  const inches = Math.max(0.8, Math.min(Number(ability.rangeInches || ability.placeInches || 1), ability.effectKind === "marker" ? 4 : Number(ability.placeInches || ability.rangeInches || 1)));
  const direction = piece.sideKey === "player1" ? 1 : -1;
  return {
    xInches: round(clamp(piece.xInches + direction * inches, 0, state.board.widthInches), 2),
    yInches: round(clamp(piece.yInches + (ability.effectKind === "marker" ? 0.75 : 0), 0, state.board.heightInches), 2),
  };
}

export function currentSupplyForPiece(piece = {}) {
  if (!piece.isOnField || piece.isDestroyed || Number(piece.currentModels || 0) <= 0) return 0;
  const baseSupply = Math.max(0, Number(piece.supply || 0));
  if (baseSupply === 0) return 0;
  const currentModels = Number(piece.currentModels || 0);
  const maxModels = Math.max(1, Number(piece.maxModels || currentModels || 1));
  if (maxModels > 1 && currentModels <= Math.ceil(maxModels / 3)) return Math.max(1, baseSupply - 1);
  return baseSupply;
}

export function supplyPoolForRound(state, sideKey = state.activeSideKey) {
  const mission = state.mission || {};
  const start = Number(mission.startingSupply || 8);
  const escalation = String(mission.extraSupply || "2 per round").match(/(\d+)/)?.[1] || "2";
  const gameLength = Number(mission.gameLength || 4);
  if (state.round >= gameLength) return 999;
  return start + Number(escalation) * Math.max(0, state.round - 1);
}

export function usedSupply(state, sideKey = state.activeSideKey) {
  return activePieces(state, sideKey).reduce((sum, piece) => sum + currentSupplyForPiece(piece), 0);
}

function availableSupply(state, sideKey = state.activeSideKey) {
  return supplyPoolForRound(state, sideKey) - usedSupply(state, sideKey);
}

function candidate(action, enabled = true, reason = "", score = 0, details = {}) {
  return { ...action, isEnabled: Boolean(enabled), disabledReason: enabled ? "" : reason, score: round(score), details };
}

function engagingEnemies(state, piece) {
  return enemyPieces(state, piece.sideKey).filter((enemy) => baseEdgeDistance(piece, enemy) <= 0.1);
}

function hasPhaseActivationAvailable(state, sideKey, phase) {
  if (state.players?.[sideKey]?.passedPhases?.[phase]) return false;
  if (phase === "movement") {
    if (activePieces(state, sideKey).some((piece) => !activated(piece, phase))) return true;
    return reservePieces(state, sideKey).some((piece) => !activated(piece, phase) && availableSupply(state, sideKey) >= currentSupplyForPiece({ ...piece, isOnField: true }));
  }
  if (phase === "assault" || phase === "combat") return activePieces(state, sideKey).some((piece) => !activated(piece, phase));
  return false;
}

function sidePassedPhase(state, sideKey, phase = state.phase) {
  return Boolean(state.players?.[sideKey]?.passedPhases?.[phase]);
}

function allSidesPassedPhase(state, phase = state.phase) {
  return SIDE_KEYS.every((sideKey) => sidePassedPhase(state, sideKey, phase));
}

function shouldAdvanceStarcraftPhase(state, phase = state.phase) {
  if (phase === "scoring") return allScoringSidesResolved(state);
  if (!["movement", "assault", "combat"].includes(phase)) return false;
  if (allSidesPassedPhase(state, phase)) return true;
  return SIDE_KEYS.every((sideKey) => !hasPhaseActivationAvailable(state, sideKey, phase));
}

function clearPassedPhase(state, phase) {
  for (const sideKey of SIDE_KEYS) {
    state.players[sideKey].passedPhases = state.players[sideKey].passedPhases || {};
    delete state.players[sideKey].passedPhases[phase];
  }
}

function alternateActiveSideAfterActivation(state, sideKey, phase) {
  if (!["movement", "assault", "combat"].includes(phase)) return;
  const other = sideKey === "player1" ? "player2" : "player1";
  if (hasPhaseActivationAvailable(state, other, phase)) state.activeSideKey = other;
  else state.activeSideKey = sideKey;
}

export function enumerateStarcraftTmgLegalActions(inputState, options = {}) {
  const state = normalizeStarcraftTmgState(inputState);
  const sideKey = options.sideKey || state.activeSideKey;
  const phase = options.phase || state.phase;
  const includeDisabled = options.includeDisabled !== false;
  const candidates = [];

  if (state.gameOver) {
    return {
      schemaVersion: "starcraft_tmg_legal_actions_v0",
      stateSummary: { round: state.round, phase, activeSideKey: sideKey, supplyPool: supplyPoolForRound(state, sideKey), usedSupply: usedSupply(state, sideKey), availableSupply: availableSupply(state, sideKey) },
      terminal: { gameOver: true, winner: state.winner || "", reason: state.terminalReason || "" },
      candidates,
      disabledCount: 0,
    };
  }

  if (phase === "movement") {
    for (const piece of reservePieces(state, sideKey)) {
      const requiredSupply = currentSupplyForPiece({ ...piece, isOnField: true });
      const enabled = availableSupply(state, sideKey) >= requiredSupply && !activated(piece, phase);
      candidates.push(candidate({
        actionType: "deploy",
        sideKey,
        pieceId: piece.id,
        xInches: sideKey === "player1" ? 4 : state.board.widthInches - 4,
        yInches: piece.yInches || state.board.heightInches / 2,
      }, enabled, enabled ? "" : "insufficient_supply_or_already_activated", enabled ? 7 : -5, { supply: requiredSupply, availableSupply: availableSupply(state, sideKey) }));
    }
    for (const piece of activePieces(state, sideKey)) {
      const threatProfile = threatProfileForPiece(state, piece);
      const enabled = !activated(piece, phase);
      const target = enemyPieces(state, sideKey).sort((a, b) => distance(piece, a) - distance(piece, b))[0];
      const speed = threatProfile.effectiveSpeed;
      const engagedBy = engagingEnemies(state, piece);
      if (engagedBy.length) {
        const enemySupply = engagedBy.reduce((sum, enemy) => sum + currentSupplyForPiece(enemy), 0);
        const ownSupply = currentSupplyForPiece(piece);
        const center = engagedBy.reduce((acc, enemy) => ({ x: acc.x + enemy.xInches / engagedBy.length, y: acc.y + enemy.yInches / engagedBy.length }), { x: 0, y: 0 });
        const away = Math.atan2(piece.yInches - center.y, piece.xInches - center.x);
        const destination = {
          xInches: clamp(piece.xInches + Math.cos(away) * speed, 0, state.board.widthInches),
          yInches: clamp(piece.yInches + Math.sin(away) * speed, 0, state.board.heightInches),
        };
        const path = evaluateStarcraftTmgTerrainPath(state, piece.id, destination);
        const overlaps = hasBaseOverlapAt(state, piece, destination);
        const disengageEnabled = enabled && !path.blocked && path.totalCostInches <= speed + 0.01 && !overlaps;
        candidates.push(candidate({
          actionType: "disengage",
          sideKey,
          pieceId: piece.id,
          to: destination,
        }, disengageEnabled, !enabled ? "already_activated_this_phase" : overlaps ? "base_overlap" : path.blocked ? "terrain_path_blocked" : "terrain_path_exceeds_speed", disengageEnabled ? 3 : -4, {
          speed,
          engagedBy: engagedBy.map((enemy) => enemy.id),
          ownCurrentSupply: ownSupply,
          engagingEnemyCurrentSupply: enemySupply,
          tacticalMass: ownSupply > enemySupply,
          terrainPath: path,
        }));
      }
      const rawDx = target ? target.xInches - piece.xInches : (sideKey === "player1" ? speed : -speed);
      const rawDy = target ? target.yInches - piece.yInches : 0;
      const rawDistance = Math.hypot(rawDx, rawDy) || 1;
      const stepRatio = Math.min(speed, rawDistance) / rawDistance;
      const dx = rawDx * stepRatio;
      const dy = rawDy * stepRatio;
      const destination = {
        xInches: clamp(piece.xInches + dx, 0, state.board.widthInches),
        yInches: clamp(piece.yInches + dy, 0, state.board.heightInches),
      };
      const path = evaluateStarcraftTmgTerrainPath(state, piece.id, destination);
      const overlaps = hasBaseOverlapAt(state, piece, destination);
      const moveEnabled = enabled && !path.blocked && path.totalCostInches <= speed + 0.01 && !overlaps;
      candidates.push(candidate({
        actionType: "move",
        sideKey,
        pieceId: piece.id,
        to: destination,
      }, moveEnabled, !enabled ? "already_activated_this_phase" : overlaps ? "base_overlap" : path.blocked ? "terrain_path_blocked" : "terrain_path_exceeds_speed", moveEnabled ? 4 : -4, { speed, targetId: target?.id || null, terrainPath: path }));
      candidates.push(candidate({ actionType: "hold", sideKey, pieceId: piece.id }, enabled, "already_activated_this_phase", 1));
    }
  }

  if (phase === "assault") {
    for (const piece of activePieces(state, sideKey)) {
      const threatProfile = threatProfileForPiece(state, piece);
      const disengagedLimited = (piece.statuses || []).includes("disengaged_limited");
      for (const target of enemyPieces(state, sideKey)) {
        const dist = baseEdgeDistance(piece, target);
        for (const weapon of weaponsForPhase(piece, "assault").filter((item) => hasTargetMatch(item, target))) {
          const range = effectiveWeaponRange(piece, weapon).rangeInches + Math.max(0, threatProfile.bestRange - Math.max(threatProfile.bestRanged, threatProfile.meleeReach));
          const los = evaluateStarcraftTmgLineOfSight(state, piece.id, target.id);
          const indirect = parseKeywords(`${piece.keywords || ""} ${weapon.keywords || ""}`).some((keyword) => keyword.type === "indirect_fire");
          const enabled = !disengagedLimited && !activated(piece, phase) && dist <= range && (los.hasLineOfSight || indirect);
          const estimate = resolveStarcraftCombat({ attacker: piece, defender: target, weapon, distanceInches: dist, context: { defenderCanEvade: los.cover.length > 0 } });
          candidates.push(candidate({
            actionType: "shoot",
            sideKey,
            pieceId: piece.id,
            targetId: target.id,
            weaponName: weapon.name,
          }, enabled, enabled ? "" : disengagedLimited ? "disengaged_without_tactical_mass" : activated(piece, phase) ? "already_activated_this_phase" : dist > range ? "target_out_of_range" : "no_line_of_sight", estimate.expectedDamage + estimate.expectedKills * 3, { distanceInches: round(dist), range, expectedDamage: estimate.expectedDamage, expectedKills: estimate.expectedKills, combat: estimate, lineOfSight: los, indirect }));
        }
        const meleeWeapon = bestWeaponForPhase(piece, "charge", target);
        const meleeReach = meleeWeapon ? Math.max(threatProfile.meleeReach, parseRange(meleeWeapon.range)) : threatProfile.meleeReach;
        const chargeRange = threatProfile.moveChargeMeleeThreat;
        const chargeDestination = contactDestination(piece, target, meleeReach);
        const chargePath = evaluateStarcraftTmgTerrainPath(state, piece.id, chargeDestination);
        const overlaps = hasBaseOverlapAt(state, piece, chargeDestination);
        const chargeProbability = chargeSuccessProbability(Math.max(dist - meleeReach, chargePath.totalCostInches), threatProfile);
        const enabled = !disengagedLimited && Boolean(meleeWeapon) && !activated(piece, phase) && chargeProbability > 0 && dist <= chargeRange && !chargePath.blocked && !overlaps;
        if (meleeWeapon || includeDisabled) {
          const estimate = meleeWeapon ? resolveStarcraftCombat({ attacker: piece, defender: target, weapon: meleeWeapon, distanceInches: 1, context: { isCharge: true, targetEngaged: true } }) : { expectedDamage: 0, expectedKills: 0 };
          candidates.push(candidate({
            actionType: "charge",
            sideKey,
            pieceId: piece.id,
            targetId: target.id,
            weaponName: meleeWeapon?.name || null,
          }, enabled, enabled ? "" : disengagedLimited ? "disengaged_without_tactical_mass" : !meleeWeapon ? "no_melee_weapon" : activated(piece, phase) ? "already_activated_this_phase" : overlaps ? "base_overlap" : dist > chargeRange || chargeProbability <= 0 ? "target_out_of_charge_probability_band" : "terrain_path_blocked", enabled ? (estimate.expectedDamage + estimate.expectedKills * 3 + 5) * chargeProbability : -3, { distanceInches: round(dist), chargeRange: round(chargeRange, 2), chargeProbability, expectedDamage: estimate.expectedDamage, expectedKills: estimate.expectedKills, combat: estimate, terrainPath: chargePath }));
        }
      }
      const holdEnabled = !activated(piece, phase);
      candidates.push(candidate({ actionType: "hold", sideKey, pieceId: piece.id }, holdEnabled, "already_activated_this_phase", 1));
    }
  }

  if (phase === "combat") {
    for (const piece of activePieces(state, sideKey)) {
      const threatProfile = threatProfileForPiece(state, piece);
      for (const target of enemyPieces(state, sideKey)) {
        const dist = baseEdgeDistance(piece, target);
        const weapon = bestWeaponForPhase(piece, "combat", target);
        const meleeReach = weapon ? Math.max(threatProfile.meleeReach, parseRange(weapon.range)) : threatProfile.meleeReach;
        const enabled = Boolean(weapon) && !activated(piece, phase) && dist <= meleeReach + 0.01;
        if (weapon || includeDisabled) {
          const estimate = weapon ? resolveStarcraftCombat({ attacker: piece, defender: target, weapon, distanceInches: dist }) : { expectedDamage: 0, expectedKills: 0 };
          candidates.push(candidate({
            actionType: "fight",
            sideKey,
            pieceId: piece.id,
            targetId: target.id,
            weaponName: weapon?.name || null,
          }, enabled, enabled ? "" : !weapon ? "no_melee_weapon" : activated(piece, phase) ? "already_activated_this_phase" : "not_in_melee_reach", estimate.expectedDamage + estimate.expectedKills * 4, { distanceInches: round(dist), meleeReach: round(meleeReach, 2), expectedDamage: estimate.expectedDamage, expectedKills: estimate.expectedKills, combat: estimate }));
        }
      }
      const holdEnabled = !activated(piece, phase);
      candidates.push(candidate({ actionType: "hold", sideKey, pieceId: piece.id }, holdEnabled, "already_activated_this_phase", 1));
    }
  }

  if (["movement", "assault", "combat"].includes(phase)) {
    for (const piece of activePieces(state, sideKey)) {
      for (const ability of battleAbilitiesForPiece(piece).filter((item) => item.kind === "active")) {
        const phaseOk = abilityMatchesPhase(ability, phase);
        const onceOk = !(piece.usedActiveAbilities || []).includes(ability.id);
        const resourceOk = abilityResourceEnabled(state, sideKey, ability);
        const executable = ability.executable && ["marker", "status", "place", "text"].includes(ability.effectKind);
        const enabled = !activated(piece, phase) && phaseOk && onceOk && resourceOk && executable;
        const destination = ["marker", "place"].includes(ability.effectKind) ? abilityDestination(state, piece, ability) : {};
        candidates.push(candidate({
          actionType: "use_ability",
          sideKey,
          pieceId: piece.id,
          abilityId: ability.id,
          abilityName: ability.name,
          to: destination,
        }, enabled, enabled ? "" : !executable ? "ability_text_review_only" : activated(piece, phase) ? "already_activated_this_phase" : !phaseOk ? "wrong_phase" : !onceOk ? "ability_already_used_this_round" : "insufficient_resource", enabled ? 4 : -2, {
          abilityKind: ability.kind,
          abilityEffectKind: ability.effectKind,
          markerLabel: ability.markerLabel,
          statusName: ability.statusName,
          resourceCost: ability.resourceCost,
          rangeInches: ability.rangeInches || ability.placeInches,
        }));
      }
    }
  }

  if (phase === "scoring") {
    const alreadyScored = scoringResolvedForSide(state, sideKey);
    candidates.push(candidate(
      { actionType: "score_marker", sideKey },
      !alreadyScored,
      alreadyScored ? "already_scored_this_scoring_phase" : "",
      alreadyScored ? -10 : 3,
      { scoringResolvedThisPhase: state.scoringResolvedThisPhase },
    ));
  }

  for (const [resourceSideKey, cards] of Object.entries(state.cardResources || {})) {
    if (resourceSideKey !== sideKey) continue;
    for (const [index, card] of (cards || []).entries()) {
      const enabled = Number(card.currentResource || 0) > 0 && !card.usedThisRound;
      candidates.push(candidate({
        actionType: "use_card_resource",
        sideKey,
        cardResourceId: card.id,
        cardIndex: index,
        amount: 1,
      }, enabled, enabled ? "" : "card_exhausted_or_empty", enabled ? 0.5 : -1, { cardName: card.name, resourceType: card.resourceType, currentResource: card.currentResource }));
    }
  }

  const alreadyPassed = sidePassedPhase(state, sideKey, phase);
  const phaseShouldAdvance = shouldAdvanceStarcraftPhase(state, phase);
  candidates.push(candidate(
    { actionType: "pass", sideKey, phase },
    !alreadyPassed,
    alreadyPassed ? "already_passed_this_phase" : "",
    0,
  ));
  candidates.push(candidate(
    { actionType: "advance_phase", sideKey },
    true,
    "",
    phaseShouldAdvance ? 8 : -1,
    { scoringResolvedThisPhase: state.scoringResolvedThisPhase, phaseShouldAdvance },
  ));

  return {
    schemaVersion: "starcraft_tmg_legal_actions_v0",
    stateSummary: { round: state.round, phase, activeSideKey: sideKey, supplyPool: supplyPoolForRound(state, sideKey), usedSupply: usedSupply(state, sideKey), availableSupply: availableSupply(state, sideKey) },
    candidates: includeDisabled ? candidates : candidates.filter((item) => item.isEnabled),
    disabledCount: candidates.filter((item) => !item.isEnabled).length,
  };
}

export function resolveStarcraftCombat({ attacker, defender, weapon, distanceInches = 0, context = {} }) {
  const allKeywords = [...parseKeywords(pieceKeywordText(attacker)), ...parseKeywords(weapon.keywords)];
  const defenderKeywords = parseKeywords(pieceKeywordText(defender));
  const steps = [];
  let roa = parseExpectedValue(weapon.roa);
  const burst = allKeywords.find((keyword) => keyword.type === "burst_fire");
  if (burst && distanceInches <= Number(burst.range || 0)) roa += Number(burst.bonus || 0);
  const locked = allKeywords.find((keyword) => keyword.type === "locked_in");
  if (locked && context.targetMovedThisRound === false) roa += Number(locked.bonus || 0);
  const attackDice = Math.max(0, Math.round(Number(attacker.currentModels || 0) * roa));
  const hitTarget = parseTargetNumber(weapon.hit);
  const hitProbability = successProbability(hitTarget);
  let expectedHits = attackDice * hitProbability;
  const baseExpectedHits = expectedHits;
  const precision = keywordMax(allKeywords, "precision", "count");
  const precisionAdded = Math.min(precision, Math.max(0, attackDice - expectedHits));
  expectedHits += precisionAdded;
  steps.push({
    step: "attack_pool",
    label: "Attack Pool",
    value: round(expectedHits),
    description: `${attacker.currentModels} models x ${round(roa, 2)} RoA = ${attackDice} dice on ${hitTarget}+; ${round(baseExpectedHits)} hits${precisionAdded ? ` + ${round(precisionAdded)} Precision` : ""}.`,
  });

  let impactDamage = 0;
  const impact = allKeywords.find((keyword) => keyword.type === "impact");
  const defenderHidden = defenderKeywords.some((keyword) => keyword.type === "hidden");
  if (impact && context.isCharge && !defenderHidden) {
    const impactBonus = keywordMax(allKeywords, "impact_bonus", "dice");
    const impactDicePerModel = Number(impact.dice || 0) + impactBonus;
    const impactDice = Math.max(0, Math.round(Number(attacker.currentModels || 0) * impactDicePerModel));
    const impactTarget = parseTargetNumber(impact.hit);
    const impactHits = impactDice * successProbability(impactTarget);
    const impactArmourTarget = parseTargetNumber(defender.stats?.armor, 7);
    const impactArmourProbability = impactArmourTarget >= 7 ? 0 : successProbability(impactArmourTarget);
    const impactTough = keywordMax(defenderKeywords, "tough", "count");
    const impactSaves = Math.min(impactHits, impactHits * impactArmourProbability + Math.min(impactTough, impactHits * (1 - impactArmourProbability)));
    let impactDamageDice = Math.max(0, impactHits - impactSaves);
    const impactCanEvade = Boolean(context.defenderCanEvade || defenderHidden || context.targetEngaged);
    const impactEvadeTarget = parseTargetNumber(defender.stats?.evade, 7);
    const impactEvadeProbability = impactCanEvade && impactEvadeTarget < 7 ? successProbability(impactEvadeTarget) : 0;
    const impactEvadeSaves = impactDamageDice * impactEvadeProbability;
    impactDamageDice = Math.max(0, impactDamageDice - impactEvadeSaves);
    impactDamage = impactDamageDice;
    steps.push({
      step: "impact_pool",
      label: "Impact",
      value: round(impactDamage),
      description: `${impactDice} Impact dice on ${impactTarget}+ resolve separately with damage 1; ${round(impactDamage)} expected damage after defence.`,
    });
  } else if (impact && context.isCharge && defenderHidden) {
    steps.push({ step: "impact_pool", label: "Impact", value: 0, description: "Hidden target prevents IMPACT." });
  }

  const surge = parseSurge(weapon.surge);
  const defenderTags = splitTags(defender.tags);
  let armourPool = expectedHits;
  let surgeBypassed = 0;
  let criticalBypassed = 0;
  let dodgeBudget = keywordMax(defenderKeywords, "dodge", "count");
  let dodgePrevented = 0;
  if (surge.tags.some((tag) => defenderTags.includes(tag))) {
    const rawSurgeBypass = Math.min(surge.dice, armourPool);
    const dodgeUsed = Math.min(dodgeBudget, rawSurgeBypass);
    dodgeBudget -= dodgeUsed;
    dodgePrevented += dodgeUsed;
    const appliedSurgeBypass = rawSurgeBypass - dodgeUsed;
    armourPool -= appliedSurgeBypass;
    surgeBypassed += appliedSurgeBypass;
  }
  const critical = keywordMax(allKeywords, "critical_hit", "count");
  if (critical) {
    const rawCriticalBypass = Math.min(critical, armourPool);
    const dodgeUsed = Math.min(dodgeBudget, rawCriticalBypass);
    dodgeBudget -= dodgeUsed;
    dodgePrevented += dodgeUsed;
    const appliedCriticalBypass = rawCriticalBypass - dodgeUsed;
    armourPool -= appliedCriticalBypass;
    criticalBypassed += appliedCriticalBypass;
  }
  const bypassed = surgeBypassed + criticalBypassed;
  steps.push({
    step: "surge_pool",
    label: "Surge / Critical",
    value: round(bypassed),
    description: `${round(bypassed)} dice bypass Armour${dodgePrevented ? ` after DODGE prevents ${round(dodgePrevented)}` : ""}; ${round(armourPool)} dice remain in Armour Pool.`,
  });

  const armourTarget = parseTargetNumber(defender.stats?.armor, 7);
  const armourProbability = armourTarget >= 7 ? 0 : successProbability(armourTarget);
  const tough = keywordMax(defenderKeywords, "tough", "count");
  const expectedArmourFails = armourPool * (1 - armourProbability);
  const armourSaves = Math.min(armourPool, armourPool * armourProbability + Math.min(tough, expectedArmourFails));
  let damagePool = Math.max(0, armourPool - armourSaves) + bypassed;
  steps.push({
    step: "armour_pool",
    label: "Armour Pool",
    value: round(Math.max(0, armourPool - armourSaves)),
    description: `${round(armourPool)} dice roll Armour ${armourTarget >= 7 ? "-" : `${armourTarget}+`}; ${round(armourSaves)} saved, ${round(Math.max(0, armourPool - armourSaves))} enter Damage Pool plus ${round(bypassed)} bypass dice.`,
  });

  const canEvade = Boolean(context.defenderCanEvade || defenderKeywords.some((keyword) => keyword.type === "hidden") || (weaponKind(weapon) === "ranged" && context.targetEngaged) || (allKeywords.some((keyword) => keyword.type === "indirect_fire") && context.targetVisible === false));
  const antiEvade = keywordMax(allKeywords, "anti_evade", "modifier");
  const evadeTarget = parseTargetNumber(defender.stats?.evade, 7) + antiEvade;
  const evadeProbability = canEvade && evadeTarget < 7 ? successProbability(evadeTarget) : 0;
  const evadeSaves = damagePool * evadeProbability;
  damagePool = Math.max(0, damagePool - evadeSaves);
  steps.push({
    step: "evade_pool",
    label: "Evade Pool",
    value: round(damagePool),
    description: canEvade && evadeTarget < 7
      ? `${round(damagePool + evadeSaves)} Damage Pool dice roll Evade ${evadeTarget}+; ${round(evadeSaves)} evaded and ${round(damagePool)} remain.`
      : "No Evade Roll applies for this attack preview.",
  });

  let damagePerDie = parseExpectedValue(weapon.dmg) || 1;
  const titanKiller = weaponKind(weapon) === "melee" ? matchingTitanKiller(allKeywords, parseExpectedValue(defender.stats?.size)) : null;
  if (titanKiller) damagePerDie = Math.max(damagePerDie, Number(titanKiller.damage || damagePerDie));
  const pierce = matchingPierce(allKeywords, defender.tags);
  if (pierce) damagePerDie = Number(pierce.damage || damagePerDie);
  const expectedDamageBeforeCap = damagePool * damagePerDie + impactDamage;
  const durability = Math.max(1, parseExpectedValue(defender.stats?.hp) + parseExpectedValue(defender.stats?.shield));
  const concentratedFireMax = keywordMax(allKeywords, "concentrated_fire", "maxKills") || Infinity;
  const expectedKills = Math.min(Number(defender.currentModels || 0), concentratedFireMax, expectedDamageBeforeCap / durability);
  const expectedDamage = Number.isFinite(concentratedFireMax)
    ? Math.min(expectedDamageBeforeCap, concentratedFireMax * durability)
    : expectedDamageBeforeCap;
  steps.push({
    step: "damage_pool",
    label: "Damage Pool",
    value: round(expectedDamage),
    description: `${round(damagePool)} damage dice x ${damagePerDie} damage${impactDamage ? ` + ${round(impactDamage)} Impact` : ""} = ${round(expectedDamage)} expected damage, ${round(expectedKills)} expected kills.`,
  });

  return {
    schemaVersion: "starcraft_tmg_combat_expectation_v0",
    weaponName: weapon.name,
    attackDice,
    hitTarget,
    hitProbability: round(hitProbability),
    baseExpectedHits: round(baseExpectedHits),
    expectedHits: round(expectedHits),
    precisionAdded: round(precisionAdded),
    surgeBypassed: round(surgeBypassed),
    criticalBypassed: round(criticalBypassed),
    dodgePrevented: round(dodgePrevented),
    bypassedDamagePoolDice: round(bypassed),
    armourPool: round(armourPool),
    armourSaves: round(armourSaves),
    armourFails: round(Math.max(0, armourPool - armourSaves)),
    damagePoolDice: round(damagePool),
    evadeSaves: round(evadeSaves),
    damagePerDie,
    impactDamage: round(impactDamage),
    expectedDamage: round(expectedDamage),
    expectedKills: round(expectedKills),
    durabilityPerModel: durability,
    maxKills: Number.isFinite(concentratedFireMax) ? concentratedFireMax : null,
    poolBreakdown: {
      attackPoolDice: attackDice,
      armourPoolDice: round(armourPool),
      bypassedDamagePoolDice: round(bypassed),
      damagePoolBeforeEvade: round(damagePool + evadeSaves),
      damagePoolDice: round(damagePool),
    },
    steps,
    activeKeywords: allKeywords.map((keyword) => keyword.type),
    summary: `${attacker.name} ${weapon.name} -> ${defender.name}: ${round(expectedDamage)} expected damage, ${round(expectedKills)} expected kills.`,
  };
}

function findPiece(state, pieceId) {
  return state.pieces.find((piece) => piece.id === pieceId) || null;
}

function weaponByName(piece, name) {
  return (piece.weapons || []).find((weapon) => weapon.name === name) || null;
}

function markActivated(piece, phase) {
  if (["movement", "assault", "combat"].includes(phase)) piece.activatedPhases[phase] = true;
}

function applyDamageToDefender(state, defender, combat) {
  const beforeModels = defender.currentModels;
  const beforeSupply = currentSupplyForPiece(defender);
  const perModel = Math.max(1, combat.durabilityPerModel || parseExpectedValue(defender.stats?.hp) || 1);
  const totalDamage = Number(defender.damageMarker || 0) + Number(combat.expectedDamage || 0);
  const casualties = Math.min(defender.currentModels, Math.floor(totalDamage / perModel));
  defender.currentModels = Math.max(0, defender.currentModels - casualties);
  defender.damageMarker = defender.currentModels > 0 ? round(totalDamage - casualties * perModel, 2) : 0;
  if (defender.currentModels <= 0) {
    defender.isDestroyed = true;
    defender.isOnField = false;
  }
  const afterSupply = currentSupplyForPiece(defender);
  const supplyDestroyed = beforeModels > 0 ? Math.max(0, beforeSupply - afterSupply) : 0;
  if (supplyDestroyed > 0) {
    const scoringSide = defender.sideKey === "player1" ? "player2" : "player1";
    state.supplyDestroyedThisRound[scoringSide] = (state.supplyDestroyedThisRound[scoringSide] || 0) + supplyDestroyed;
  }
  return { casualties, supplyDestroyed };
}

function spendAbilityResource(state, sideKey, ability) {
  const cost = ability.resourceCost;
  if (!cost || Number(cost.amount || 0) <= 0) return null;
  let remaining = Number(cost.amount || 0);
  for (const card of state.cardResources?.[sideKey] || []) {
    if (remaining <= 0 || String(card.resourceType || "").toUpperCase() !== String(cost.type || "").toUpperCase()) continue;
    const spend = Math.min(Number(card.currentResource || 0), remaining);
    card.currentResource = Math.max(0, Number(card.currentResource || 0) - spend);
    card.usedThisRound = true;
    remaining -= spend;
  }
  return { amount: Number(cost.amount || 0), type: cost.type };
}

function toggleStatus(piece, statusName) {
  const normalized = String(statusName || "").toUpperCase();
  const statuses = new Set((piece.statuses || []).map((status) => String(status).toUpperCase()));
  if (statuses.has(normalized)) statuses.delete(normalized);
  else statuses.add(normalized);
  piece.statuses = Array.from(statuses);
}

function actionPoint(value = {}) {
  return { xInches: round(Number(value.xInches || 0), 2), yInches: round(Number(value.yInches || 0), 2) };
}

function applyUnitAbility(state, piece, ability, matching = {}) {
  piece.usedActiveAbilities = Array.from(new Set([...(piece.usedActiveAbilities || []), ability.id]));
  const spent = spendAbilityResource(state, piece.sideKey, ability);
  if (ability.effectKind === "marker") {
    const to = actionPoint(matching.to || abilityDestination(state, piece, ability));
    const marker = {
      id: `${piece.id}-${ability.id}`,
      sideKey: piece.sideKey,
      sourcePieceId: piece.id,
      sourceAbilityId: ability.id,
      name: ability.name,
      label: ability.markerLabel || ability.name,
      xInches: to.xInches,
      yInches: to.yInches,
      radiusInches: ability.markerRadiusInches || 0.6,
      auraInches: ability.markerAuraInches,
      keywords: ability.keywords || [],
      description: ability.description || "",
      createdRound: state.round,
      expiresAt: /END OF THE ROUND/i.test(ability.description || "") ? "end_of_round" : undefined,
    };
    state.board.effectMarkers = [...(state.board.effectMarkers || []).filter((item) => item.id !== marker.id), marker];
    markActivated(piece, state.phase);
    return { type: "ability_marker", pieceId: piece.id, abilityName: ability.name, marker, spent };
  }
  if (ability.effectKind === "status" && ability.statusName) {
    toggleStatus(piece, ability.statusName);
    markActivated(piece, state.phase);
    return { type: "ability_status", pieceId: piece.id, abilityName: ability.name, statusName: ability.statusName, statuses: piece.statuses, spent };
  }
  if (ability.effectKind === "place") {
    const to = actionPoint(matching.to || abilityDestination(state, piece, ability));
    piece.xInches = to.xInches;
    piece.yInches = to.yInches;
    markActivated(piece, state.phase);
    return { type: "ability_place", pieceId: piece.id, abilityName: ability.name, xInches: piece.xInches, yInches: piece.yInches, spent };
  }
  markActivated(piece, state.phase);
  return { type: "ability_used", pieceId: piece.id, abilityName: ability.name, spent };
}

export function applyStarcraftTmgAction(inputState, action = {}) {
  const state = normalizeStarcraftTmgState(inputState);
  const phase = state.phase;
  const piece = action.pieceId ? findPiece(state, action.pieceId) : null;
  const events = [];
  const legal = enumerateStarcraftTmgLegalActions(state, { sideKey: action.sideKey || state.activeSideKey, includeDisabled: true }).candidates;
  const matching = legal.find((candidate) => {
    if (candidate.actionType !== action.actionType) return false;
    if (action.pieceId && candidate.pieceId !== action.pieceId) return false;
    if (action.targetId && candidate.targetId !== action.targetId) return false;
    if (action.weaponName && candidate.weaponName !== action.weaponName) return false;
    if (action.cardResourceId && candidate.cardResourceId !== action.cardResourceId) return false;
    if (action.abilityId && candidate.abilityId !== action.abilityId) return false;
    return true;
  });
  if (matching && !matching.isEnabled) {
    return { ok: false, reason: matching.disabledReason, state, events: [], action };
  }

  if (action.actionType === "deploy" && piece) {
    piece.isOnField = true;
    piece.xInches = clamp(Number(action.xInches ?? piece.xInches), 0, state.board.widthInches);
    piece.yInches = clamp(Number(action.yInches ?? piece.yInches), 0, state.board.heightInches);
    markActivated(piece, "movement");
    events.push({ type: "deploy", pieceId: piece.id, name: piece.name, xInches: piece.xInches, yInches: piece.yInches });
  } else if (action.actionType === "move" && piece) {
    const to = action.to || {};
    piece.xInches = clamp(Number(to.xInches ?? piece.xInches), 0, state.board.widthInches);
    piece.yInches = clamp(Number(to.yInches ?? piece.yInches), 0, state.board.heightInches);
    markActivated(piece, "movement");
    events.push({ type: "move", pieceId: piece.id, name: piece.name, xInches: piece.xInches, yInches: piece.yInches });
  } else if (action.actionType === "disengage" && piece) {
    const matchingDetails = matching?.details || {};
    const to = action.to || {};
    piece.xInches = clamp(Number(to.xInches ?? piece.xInches), 0, state.board.widthInches);
    piece.yInches = clamp(Number(to.yInches ?? piece.yInches), 0, state.board.heightInches);
    piece.statuses = (piece.statuses || []).filter((status) => !["disengaged_limited", "tactical_mass_disengage"].includes(status));
    piece.statuses.push(matchingDetails.tacticalMass ? "tactical_mass_disengage" : "disengaged_limited");
    markActivated(piece, "movement");
    events.push({
      type: "disengage",
      pieceId: piece.id,
      name: piece.name,
      xInches: piece.xInches,
      yInches: piece.yInches,
      tacticalMass: Boolean(matchingDetails.tacticalMass),
      ownCurrentSupply: matchingDetails.ownCurrentSupply || currentSupplyForPiece(piece),
      engagingEnemyCurrentSupply: matchingDetails.engagingEnemyCurrentSupply || 0,
    });
  } else if (["shoot", "fight", "charge"].includes(action.actionType) && piece) {
    const target = findPiece(state, action.targetId);
    const weapon = weaponByName(piece, action.weaponName) || bestWeaponForPhase(piece, action.actionType === "shoot" ? "assault" : "combat", target || {});
    if (!target || !weapon) return { ok: false, reason: "target_or_weapon_not_found", state, events: [], action };
    if (action.actionType === "charge") {
      const dist = baseEdgeDistance(piece, target);
      const destination = contactDestination(piece, target);
      piece.xInches = destination.xInches;
      piece.yInches = destination.yInches;
      events.push({ type: "charge_move", pieceId: piece.id, targetId: target.id, distanceBefore: round(dist), xInches: piece.xInches, yInches: piece.yInches });
    }
    const los = action.actionType === "shoot" ? evaluateStarcraftTmgLineOfSight(state, piece.id, target.id) : { cover: [] };
    const combat = resolveStarcraftCombat({
      attacker: piece,
      defender: target,
      weapon,
      distanceInches: baseEdgeDistance(piece, target),
      context: { targetEngaged: action.actionType !== "shoot", isCharge: action.actionType === "charge", defenderCanEvade: action.actionType === "shoot" && los.cover.length > 0 },
    });
    const damage = applyDamageToDefender(state, target, combat);
    markActivated(piece, action.actionType === "fight" ? "combat" : "assault");
    events.push({ type: "attack", actionType: action.actionType, attackerId: piece.id, targetId: target.id, weaponName: weapon.name, combat, damage });
  } else if (action.actionType === "hold" && piece) {
    markActivated(piece, phase);
    events.push({ type: "hold", pieceId: piece.id, phase });
  } else if (action.actionType === "use_card_resource") {
    const sideKey = action.sideKey || state.activeSideKey;
    const cards = state.cardResources?.[sideKey] || [];
    const card = cards.find((item) => item.id === action.cardResourceId) || cards[Number(action.cardIndex || 0)];
    if (!card) return { ok: false, reason: "card_resource_not_found", state, events: [], action };
    const amount = Math.max(1, Number(action.amount || 1));
    card.currentResource = Math.max(0, Number(card.currentResource || 0) - amount);
    card.usedThisRound = true;
    events.push({ type: "card_resource_used", sideKey, cardResourceId: card.id, cardName: card.name, amount, remaining: card.currentResource, resourceType: card.resourceType || "" });
  } else if (action.actionType === "use_ability" && piece) {
    const ability = battleAbilitiesForPiece(piece).find((item) => item.id === (action.abilityId || matching?.abilityId));
    if (!ability) return { ok: false, reason: "ability_not_found", state, events: [], action };
    events.push(applyUnitAbility(state, piece, ability, { ...matching, to: action.to || matching?.to }));
  } else if (action.actionType === "score_marker") {
    const scoringSideKey = action.sideKey || state.activeSideKey;
    if (scoringResolvedForSide(state, scoringSideKey)) {
      return { ok: false, reason: "already_scored_this_scoring_phase", state, events: [], action };
    }
    const scoring = resolveStarcraftTmgScoring(state, scoringSideKey);
    state.scoringResolvedThisPhase[scoringSideKey] = true;
    const other = otherSideKey(scoringSideKey);
    if (!scoringResolvedForSide(state, other)) state.activeSideKey = other;
    events.push(...scoring.events);
    events.push({ type: "scoring_side_complete", sideKey: scoringSideKey, scoringResolvedThisPhase: state.scoringResolvedThisPhase });
  } else if (action.actionType === "pass") {
    const sideKey = action.sideKey || state.activeSideKey;
    state.players[sideKey].passedPhases = state.players[sideKey].passedPhases || {};
    if (state.players[sideKey].passedPhases[phase]) {
      return { ok: false, reason: "already_passed_this_phase", state, events: [], action };
    }
    state.players[sideKey].passedPhases[phase] = true;
    if (!state.firstPassSideByPhase[phase]) {
      state.firstPassSideByPhase[phase] = sideKey;
      state.firstPlayerSideKey = sideKey;
    }
    for (const own of activePieces(state, sideKey)) markActivated(own, phase);
    events.push({ type: "pass", sideKey, phase, firstPlayerSideKey: state.firstPlayerSideKey });
    state.activeSideKey = sideKey === "player1" ? "player2" : "player1";
    if (allSidesPassedPhase(state, phase)) {
      events.push({ type: "phase_complete_by_passes", phase, round: state.round });
      state.log.push({ id: `log-${state.log.length + 1}`, round: state.round, phase, action, events: [...events], createdAt: new Date().toISOString() });
      const phaseResult = advanceStarcraftTmgPhase(state);
      return { ok: true, state: phaseResult.state, events: [...events, ...phaseResult.events], action };
    }
  } else if (action.actionType === "advance_phase") {
    const phaseResult = advanceStarcraftTmgPhase(state);
    return { ok: true, state: phaseResult.state, events: phaseResult.events, action };
  } else {
    return { ok: false, reason: "unsupported_action", state, events: [], action };
  }
  if (["deploy", "move", "disengage", "shoot", "fight", "charge", "hold", "use_ability"].includes(action.actionType)) {
    alternateActiveSideAfterActivation(state, action.sideKey || state.activeSideKey, phase);
  }
  state.log.push({ id: `log-${state.log.length + 1}`, round: state.round, phase: state.phase, action, events, createdAt: new Date().toISOString() });
  return { ok: true, state, events, action };
}

export function resolveStarcraftTmgScoring(state, sideKey = state.activeSideKey) {
  const marker = state.board.centerMarkers?.[0] || { xInches: state.board.widthInches / 2, yInches: state.board.heightInches / 2, radiusInches: 3 };
  const ownSupply = activePieces(state, sideKey)
    .filter((piece) => distance(piece, marker) <= marker.radiusInches)
    .reduce((sum, piece) => sum + currentSupplyForPiece(piece), 0);
  const enemySupply = enemyPieces(state, sideKey)
    .filter((piece) => distance(piece, marker) <= marker.radiusInches)
    .reduce((sum, piece) => sum + currentSupplyForPiece(piece), 0);
  const destroyedSupplyVp = state.supplyDestroyedThisRound?.[sideKey] || 0;
  const markerVp = ownSupply > enemySupply ? 1 : 0;
  const vp = markerVp + destroyedSupplyVp;
  state.scores[sideKey] = (state.scores[sideKey] || 0) + vp;
  return {
    vp,
    markerVp,
    destroyedSupplyVp,
    events: [{ type: "score", sideKey, vp, markerVp, destroyedSupplyVp, ownSupply, enemySupply, markerId: marker.id || "center" }],
  };
}

export function advanceStarcraftTmgPhase(inputState, options = {}) {
  const state = normalizeStarcraftTmgState(inputState);
  const events = [];
  if (state.phase === "scoring" || options.resolveScoring) {
    for (const sideKey of SIDE_KEYS) {
      if (scoringResolvedForSide(state, sideKey)) continue;
      const scoring = resolveStarcraftTmgScoring(state, sideKey);
      state.scoringResolvedThisPhase[sideKey] = true;
      events.push(...scoring.events);
      events.push({ type: "scoring_side_complete", sideKey, scoringResolvedThisPhase: state.scoringResolvedThisPhase });
    }
  }
  const index = PHASES.indexOf(state.phase);
  const nextIndex = (index + 1) % PHASES.length;
  if (nextIndex === 0) {
    state.round += 1;
    state.supplyDestroyedThisRound = { player1: 0, player2: 0 };
    state.scoringResolvedThisPhase = { player1: false, player2: false };
    state.firstPassSideByPhase = {};
    state.players.player1.passedPhases = {};
    state.players.player2.passedPhases = {};
    for (const piece of state.pieces) {
      piece.activatedPhases = { movement: false, assault: false, combat: false };
      piece.usedActiveAbilities = [];
      piece.statuses = (piece.statuses || []).filter((status) => !["disengaged_limited", "tactical_mass_disengage"].includes(status));
    }
    state.board.effectMarkers = (state.board.effectMarkers || []).filter((marker) => marker.expiresAt !== "end_of_round");
    for (const cards of Object.values(state.cardResources || {})) {
      for (const card of cards || []) card.usedThisRound = false;
    }
    events.push({ type: "new_round", round: state.round });
  } else {
    for (const piece of state.pieces) {
      if (PHASES[nextIndex] in piece.activatedPhases) piece.activatedPhases[PHASES[nextIndex]] = false;
    }
  }
  state.phase = PHASES[nextIndex];
  clearPassedPhase(state, state.phase);
  state.activeSideKey = state.firstPlayerSideKey || "player1";
  state.players.player1.passedPhases = state.players.player1.passedPhases || {};
  state.players.player2.passedPhases = state.players.player2.passedPhases || {};
  events.push({ type: "phase_advanced", phase: state.phase, round: state.round, activeSideKey: state.activeSideKey });
  markStarcraftTerminalIfNeeded(state, events);
  state.log.push({ id: `log-${state.log.length + 1}`, round: state.round, phase: state.phase, action: { actionType: "advance_phase" }, events, createdAt: new Date().toISOString() });
  return { ok: true, phase: state.phase, state, events };
}

export function estimateStarcraftTmgThreat(stateInput, options = {}) {
  const state = normalizeStarcraftTmgState(stateInput);
  const sideKey = options.sideKey || state.activeSideKey;
  return activePieces(state, sideKey).map((piece) => {
    const profile = threatProfileForPiece(state, piece);
    const targetRows = enemyPieces(state, sideKey).map((target) => {
      const dist = baseEdgeDistance(piece, target);
      const shootCandidate = dist <= profile.moveShootThreat;
      const chargeCandidate = dist <= profile.moveChargeMeleeThreat;
      const fightCandidate = dist <= profile.meleeReach + 0.01;
      const weapon = bestWeaponForPhase(piece, shootCandidate && profile.bestRanged >= profile.meleeReach ? "assault" : "combat", target) || bestWeaponForPhase(piece, "assault", target) || bestWeaponForPhase(piece, "combat", target);
      const los = evaluateStarcraftTmgLineOfSight(state, piece.id, target.id);
      const chargeProbability = chargeCandidate ? chargeSuccessProbability(Math.max(0, dist - profile.meleeReach), profile) : 0;
      const bestThreatMode = fightCandidate ? "fight" : shootCandidate && los.hasLineOfSight ? "shoot" : chargeProbability > 0 ? "charge" : "none";
      const combat = weapon ? resolveStarcraftCombat({ attacker: piece, defender: target, weapon, distanceInches: dist, context: { defenderCanEvade: los.cover.length > 0, isCharge: bestThreatMode === "charge", targetEngaged: bestThreatMode !== "shoot" } }) : null;
      const threatNotes = [
        ...profile.modifiers.slice(0, 3).map((modifier) => modifier.note),
        ...(!los.hasLineOfSight && shootCandidate ? ["Shoot threat is blocked by LOS terrain unless an ability/weapon ignores it."] : []),
        ...(chargeProbability > 0 && chargeProbability < 1 ? [`Charge probability from this position is ${(chargeProbability * 100).toFixed(0)}%.`] : []),
      ];
      return {
        targetId: target.id,
        targetName: target.name,
        distanceInches: round(dist, 2),
        inBaseThreat: dist <= profile.baseThreat,
        inSetupThreat: dist <= profile.setupThreat,
        inMoveShootThreat: shootCandidate && los.hasLineOfSight,
        inMoveChargeMeleeThreat: chargeProbability > 0,
        hasLineOfSight: los.hasLineOfSight,
        losBlockers: los.blockers.map((blocker) => blocker.name),
        coverFrom: los.cover.map((cover) => cover.name),
        weaponName: weapon?.name || null,
        expectedDamage: combat?.expectedDamage || 0,
        expectedKills: combat?.expectedKills || 0,
        chargeProbability,
        bestThreatMode,
        threatNotes,
        killPressure: combat ? round((combat.expectedKills || 0) / Math.max(1, target.currentModels), 3) : 0,
      };
    }).sort((a, b) => Number(b.inMoveShootThreat || b.inMoveChargeMeleeThreat) - Number(a.inMoveShootThreat || a.inMoveChargeMeleeThreat) || b.expectedDamage - a.expectedDamage || a.distanceInches - b.distanceInches);
    return {
      schemaVersion: "starcraft_tmg_threat_plan_v0",
      pieceId: piece.id,
      pieceName: piece.name,
      sideKey,
      baseThreatInches: round(profile.baseThreat, 2),
      setupThreatInches: round(profile.setupThreat, 2),
      moveInches: round(profile.effectiveSpeed, 2),
      effectiveSpeedInches: round(profile.effectiveSpeed, 2),
      rangedThreatInches: round(profile.bestRanged, 2),
      meleeThreatInches: round(profile.meleeReach, 2),
      moveShootThreatInches: round(profile.moveShootThreat, 2),
      moveChargeMeleeThreatInches: round(profile.moveChargeMeleeThreat, 2),
      meleeReachInches: round(profile.meleeReach, 2),
      setupExtensionInches: round(profile.setupExtension, 2),
      chargeDiceMaxInches: round(profile.chargeDiceMax, 2),
      chargeDiceAverageInches: round(profile.chargeDiceAverage, 2),
      chargeProbabilityBands: profile.chargeProbabilityBands,
      modifiers: profile.modifiers,
      confidence: "medium",
      omittedRuleFamilies: ["exact_los_terrain", "deployment_zone_geometry", "long_form_ability_timing", "official_charge_dice_confirmation"],
      targetRows,
    };
  });
}

export function decideStarcraftTmgSimpleAi(stateInput, options = {}) {
  const state = normalizeStarcraftTmgState(stateInput);
  const sideKey = options.sideKey || state.activeSideKey;
  const legal = enumerateStarcraftTmgLegalActions(state, { sideKey, includeDisabled: true });
  const enabled = legal.candidates.filter((action) => action.isEnabled);
  const ranked = enabled.map((action) => {
    let score = Number(action.score || 0);
    if (["shoot", "fight", "charge"].includes(action.actionType)) score += Number(action.details?.expectedDamage || 0) * 2 + Number(action.details?.expectedKills || 0) * 5;
    if (action.actionType === "deploy") score += 3;
    if (action.actionType === "move") score += 1;
    return { ...action, aiScore: round(score) };
  }).sort((a, b) => b.aiScore - a.aiScore);
  const selectedAction = ranked[0] || legal.candidates.find((action) => action.actionType === "pass");
  const threat = estimateStarcraftTmgThreat(state, { sideKey });
  return {
    schemaVersion: "starcraft_tmg_simple_ai_decision_v0",
    sideKey,
    selectedAction,
    rankedActions: ranked.slice(0, options.limit || 8),
    disabledDiagnostics: legal.candidates.filter((action) => !action.isEnabled).slice(0, 12),
    threatContext: threat.slice(0, 4),
    metrics: {
      illegalChoice: selectedAction ? selectedAction.isEnabled === false : true,
      enabledActions: enabled.length,
      disabledActions: legal.disabledCount,
      confidence: enabled.length > 0 ? "medium" : "low",
    },
    expertLabelContract: { humanReviewed: false, trainingTruth: false, reviewRequiredForTrainingTruth: true },
    limitations: state.omittedRules || [],
  };
}

export function buildStarcraftTmgFullTurnPlan(stateInput, options = {}) {
  let state = normalizeStarcraftTmgState(stateInput);
  const sideKey = options.sideKey || state.activeSideKey;
  const maxSteps = options.maxSteps || 12;
  const steps = [];
  for (let index = 0; index < maxSteps; index += 1) {
    if (state.activeSideKey !== sideKey && options.stopOnSideChange !== false) break;
    const decision = decideStarcraftTmgSimpleAi(state, { sideKey });
    const action = decision.selectedAction;
    if (!action || !action.isEnabled) break;
    const applied = applyStarcraftTmgAction(state, action);
    steps.push({ index, decision, action, transition: applied, replayable: applied.ok });
    if (!applied.ok) break;
    state = applied.state;
    if (["pass", "advance_phase"].includes(action.actionType)) break;
  }
  return {
    schemaVersion: "starcraft_tmg_full_turn_plan_v0",
    sideKey,
    steps,
    finalState: state,
    humanReviewed: false,
    trainingTruth: false,
  };
}

export function runStarcraftTmgAiBenchmark(stateInput, options = {}) {
  let state = normalizeStarcraftTmgState(stateInput);
  const steps = [];
  let illegalChoices = 0;
  for (let index = 0; index < (options.maxSteps || 10); index += 1) {
    const sideKey = state.activeSideKey;
    const decision = decideStarcraftTmgSimpleAi(state, { sideKey });
    if (!decision.selectedAction?.isEnabled) illegalChoices += 1;
    const applied = applyStarcraftTmgAction(state, decision.selectedAction || { actionType: "pass", sideKey });
    steps.push({ index, sideKey, decision, appliedOk: applied.ok, events: applied.events });
    if (!applied.ok) break;
    state = applied.state;
    if (decision.selectedAction?.actionType !== "advance_phase" && activePieces(state, sideKey).every((piece) => activated(piece, state.phase))) {
      state = advanceStarcraftTmgPhase(state).state;
    }
  }
  const attacks = steps.flatMap((step) => step.events || []).filter((event) => event.type === "attack").length;
  const scoringEvents = state.log.flatMap((entry) => entry.events || []).filter((event) => event.type === "score").length;
  return {
    schemaVersion: "starcraft_tmg_ai_benchmark_v0",
    steps,
    finalScore: state.scores,
    evaluation: {
      illegalChoices,
      rulesUnderstandingScore: illegalChoices === 0 ? 1 : 0,
      playQualityScore: round(Math.min(1, 0.55 + attacks * 0.15 + scoringEvents * 0.1), 2),
      attacks,
      scoringEvents,
    },
    humanReviewed: false,
    trainingTruth: false,
  };
}

export function matrixSummary() {
  const checkItems = RULE_MATRIX.flatMap((row) => row.checkItems || []);
  return {
    rows: RULE_MATRIX.length,
    checkItems: checkItems.length,
    executableCheckItems: checkItems.filter((item) => item.type === "executable").length,
    reviewRows: RULE_MATRIX.filter((row) => row.status === "review").length,
    pendingRows: RULE_MATRIX.filter((row) => row.status === "pending").length,
    executableGaps: checkItems.filter((item) => item.type === "executable" && !item.fixtureId).length,
  };
}
